﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using SharpGL;
using DoHoaMT.ClassDuongThang;

namespace DoHoaMT.classPhepTruot
{
    class PhepTruot
    {
        public void TruotX(ref int x1, ref int x2, ref int y1, ref int y2, OpenGL gl, int dotruot)
        {
            x1 = x1 + y1 * dotruot;
            x2 = x2 + y2 * dotruot;
            
        }
        public void TruotY(ref int x1, ref int x2, ref int y1, ref int y2, OpenGL gl, int dotruot)
        {
            y1 = x1 * dotruot + y1;
            y2 = x2 * dotruot + y2;
            
        }
        public void TinhTienX(ref int x1, ref int x2, ref int y1, ref int y2, OpenGL gl, string a)
        {
            int ttx = int.Parse(a);
            x1 = x1 + ttx;
            x2 = x2 + ttx;
            
        }
        public void TinhTienY(ref int x1, ref int x2, ref int y1, ref int y2, OpenGL gl, string a)
        {
            int tty = int.Parse(a);
            y1 = y1 + tty;
            y2 = y2 + tty;
            
        }
        public void PhepQuay(ref int x1, ref int x2, ref int y1, ref int y2, OpenGL gl, string a)
        {
            float c = float.Parse(a);//chuyển đổi về dạng số
            float b;
            b = c * (float)3.14 / 180;
            int x11, x22, y11, y22;
            x11 = x1;
            x22 = x2;
            y11 = y1;
            y22 = y2;
            int xtb = (int)(x11 + x22) / 2;// lấy trung điểm làm O(0,0)
            int ytb = (int)(y11 + y22) / 2;// lấy trung điểm làm O(0,0)
            x11 = x11 - xtb;
            y11 = y11 - ytb;
            x22 = x22 - xtb;
            y22 = y22 - ytb;
            x1 = (int)(x11 * Math.Cos(b)) - (int)(y11 * Math.Sin(b));
            y1 = (int)(x11 * Math.Sin(b)) + (int)(y11 * Math.Cos(b));
            x2 = (int)(x22 * Math.Cos(b)) - (int)(y22 * Math.Sin(b));
            y2 = (int)(x22 * Math.Sin(b)) + (int)(y22 * Math.Cos(b));
            x1 = x1 + xtb;
            x2 = x2 + xtb;
            y1 = y1 + ytb;
            y2 = y2 + ytb;
            
        }
        public void PhepCoGian(ref int x1, ref int x2, ref int y1, ref int y2, OpenGL gl, int a)
        {
            
            int x11, x22, y11, y22;
            x11 = x1;
            x22 = x2;
            y11 = y1;
            y22 = y2;
            int xtb = (int)(x11 + x22) / 2;// lấy trung điểm làm O(0,0)
            int ytb = (int)(y11 + y22) / 2;// lấy trung điểm làm O(0,0)
            x11 = x11 - xtb;
            y11 = y11 - ytb;
            x22 = x22 - xtb;
            y22 = y22 - ytb;
            x1 = x11 * a;
            y1 = y11 * a;
            x2 = x22 * a;
            y2 = y22 * a;   
            x1 = x1 + xtb;
            x2 = x2 + xtb;
            y1 = y1 + ytb;
            y2 = y2 + ytb;
            
        }
        public void PhepDXOX(ref int x1, ref int x2, ref int y1, ref int y2, OpenGL gl)
        {
            int x11, x22, y11, y22;
            x11 = x1;
            x22 = x2;
            y11 = y1;
            y22 = y2;
            int xtb = (int)(x11 + x22) / 2;// lấy trung điểm làm O(0,0)
            int ytb = (int)(y11 + y22) / 2;// lấy trung điểm làm O(0,0)
            x11 = x11 - xtb;
            y11 = y11 - ytb;
            x22 = x22 - xtb;
            y22 = y22 - ytb;
            x1 = x11;
            y1 = -y11;
            x2 = x22;
            y2 = -y22;
            x1 = x1 + xtb;
            x2 = x2 + xtb;
            y1 = y1 + ytb;
            y2 = y2 + ytb;
            
        }
        public void PhepDXOY(ref int x1, ref int x2, ref int y1, ref int y2, OpenGL gl)
        {
            int x11, x22, y11, y22;
            x11 = x1;
            x22 = x2;
            y11 = y1;
            y22 = y2;
            int xtb = (int)(x11 + x22) / 2;// lấy trung điểm làm O(0,0)
            int ytb = (int)(y11 + y22) / 2;// lấy trung điểm làm O(0,0)
            x11 = x11 - xtb;
            y11 = y11 - ytb;
            x22 = x22 - xtb;
            y22 = y22 - ytb;
            x1 = -x11;
            y1 = y11;
            x2 = -x22;
            y2 = y22;
            x1 = x1 + xtb;
            x2 = x2 + xtb;
            y1 = y1 + ytb;
            y2 = y2 + ytb;
            
        }
    }
}
