﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SharpGL.SceneGraph.Assets;
using Demo.ClassCameara;
namespace demo
{
   
    public partial class Form1 : Form
    {
        string dichx;
        string dichy;
        string dichz;
        string zoomz;
        string zoomy;
        string zoomx;
        int scalex, scaley, scalez;
        string rotationx, rotationy, rotationz;
        float xoayx, xoayy, xoayz;
        int nendich = 0;
        int nenzoom = 0;
        int nenxoay = 0;
        int shShape = 0;
        int doituong=0;
        Camera cam = new Camera();
        public struct Point3d
        {
            public int x;
            public int y;
            public int z;
        }
        Point3d tamdich;
        
        public Form1()
        {
            pointControl.x = pointControl.y = pointControl.z = 0;
            InitializeComponent();
            shShape = 0;           
            object3D = new Shape[100];
            
        }

        //public class Camera
        //{
        //    public double eyex;
        //    public double eyey;
        //    public double eyez;

        //    public double upx;
        //    public double upy;
        //    public double upz;

        //    double degree;

        //    public double centerx;
        //    public double centery;
        //    public double centerz;

            //public Camera()
            //{
            //    eyex = 10;
            //    eyey = 10;
            //    eyez = 10;

            //}

            //public void NhinGan(double khoangCach)
            //{
            //    eyex /= khoangCach;
            //    eyey /= khoangCach;
            //    eyez /= khoangCach;

            //    /* centerx -= khoangCach;
            //     centery -= khoangCach;
            //     centerz -= khoangCach;*/
            //}
            //public void NhinXa(double khoangCach)
            //{
            //    eyex *= khoangCach;
            //    eyey *= khoangCach;
            //    eyez *= khoangCach;

            //    /*centerx += khoangCach;
            //    centery += khoangCach;
            //    centerz += khoangCach;*/
            //}
            //public void Ngang(double degree)// xoay quanh z
            //{
            //    degree = degree * Math.PI / 180;
            //    double x = eyex;
            //    double y = eyey;

            //    eyex = x * Math.Cos(degree) - y * Math.Sin(degree);
            //    eyey = x * Math.Sin(degree) + y * Math.Cos(degree);
            //}

            //public void Doc(double degree)// xoay quanh x
            //{
            //    //double t = (eyex * Math.Abs(eyex) + eyez * Math.Abs(eyez)) / Math.Sqrt(eyex * eyex + eyey * eyey + eyez * eyez) / Math.Sqrt(eyex * eyex + eyez * eyez);

            //    double x = 0, z = 0, y = 0;
            //    if (eyex <= 1 && eyey <= 1)
            //    {
            //        x = 0;
            //    }

            //    int flag = 1;
            //    //if(eyex <=0 )flag = -1;
            //    double t = (1 * eyex) / Math.Sqrt(eyex * eyex + eyey * eyey);
            //    double alpha = Math.Acos(t);

            //    //double sina = Math.Sqrt(1 - cosa * cosa);
            //    if ((eyex >= 0 && eyey >= 0 || eyex < 0 && eyey >= 0))
            //    {
            //        if (flag == 1)
            //            alpha = 2 * Math.PI - alpha;
            //    }

            //    x = eyex;
            //    y = eyey;

            //    eyex = x * Math.Cos(alpha) - y * Math.Sin(alpha);
            //    eyey = x * Math.Sin(alpha) + y * Math.Cos(alpha);

            //    //quay quanh y
            //    degree = degree * Math.PI / 180;
            //    z = eyez;
            //    x = eyex;

            //    eyex = x * Math.Cos(degree) + z * Math.Sin(degree);
            //    eyez = -x * Math.Sin(degree) + z * Math.Cos(degree);

            //    alpha = -alpha;

            //    x = eyex;
            //    y = eyey;

            //    eyex = x * Math.Cos(alpha) - y * Math.Sin(alpha);
            //    eyey = x * Math.Sin(alpha) + y * Math.Cos(alpha);
            //}


        //}

        public class Shape
        {
            public Point3d Center;
            public int Radius;
            public Color color;
            public Color selectedColor;

            public Shape()
            {
                Center.x = Center.y = Center.z = 0;
                
                Radius = 3;
                color = Color.White;
                selectedColor = Color.Orange;
            }

            public void Set(Point3d pt, int Radius)
            {
                this.Center = pt;
                this.Radius = Radius;
            }
            public void SetColor(Color cl)
            {
                this.color = cl;
            }
            public virtual void drawObject(OpenGL gl) { }
            public virtual void viewControlPoint(OpenGL gl) { }

            public virtual void scaledoituong(int sx,int sy,int sz) { }

            public virtual void xoaydoituong(float x,float gy,float gz) { }

            public virtual void initPoint() { }
        }
        
        public class cube : Shape
        {
            public Point3d A, B, C, D, E, F, G, H;
            public cube() : base()
            {
            }
            
            public override void initPoint()
            {
                A.x = Center.x + Radius;
                A.y = Center.y + Radius;
                A.z = Center.z + Radius;

                B.x = Center.x + Radius;
                B.y = Center.y - Radius;
                B.z = Center.z + Radius;

                C.x = Center.x - Radius;
                C.y = Center.y - Radius;
                C.z = Center.z + Radius;

                D.x = Center.x - Radius;
                D.y = Center.y + Radius;
                D.z = Center.z + Radius;

                E.x = Center.x + Radius;
                E.y = Center.y + Radius;
                E.z = Center.z - Radius;

                F.x = Center.x + Radius;
                F.y = Center.y - Radius;
                F.z = Center.z - Radius;

                G.x = Center.x - Radius;
                G.y = Center.y - Radius;
                G.z = Center.z - Radius;

                H.x = Center.x - Radius;
                H.y = Center.y + Radius;
                H.z = Center.z - Radius;

            }

            public override void drawObject(OpenGL gl)
            {
                                
                base.drawObject(gl);
                gl.Enable(OpenGL.GL_BLEND);
                gl.BlendFunc(OpenGL.GL_SRC_ALPHA, OpenGL.GL_ONE_MINUS_SRC_ALPHA);

                // đỉnh
                gl.Begin(OpenGL.GL_QUADS);//GL_QUADS là tứ giác
                gl.Color(color.R / 255.0, color.G / 255.0, color.B / 255.0, 1.0);
                gl.Vertex(A.x, A.y, A.z);
                gl.Vertex(B.x, B.y, B.z);
                gl.Vertex(C.x, C.y, C.z);
                gl.Vertex(D.x, D.y, D.z);
                gl.End();

                // đáy
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(color.R / 265.0, color.G / 265.0, color.B / 265.0, 0.9);
                gl.Vertex(E.x, E.y, E.z);
                gl.Vertex(F.x, F.y, F.z);
                gl.Vertex(G.x, G.y, G.z);
                gl.Vertex(H.x, H.y, H.z);
                gl.End();

                // mặt trước

                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(color.R / 275.0, color.G / 275.0, color.B / 275.0, 0.9);
                gl.Vertex(A.x, A.y, A.z);
                gl.Vertex(B.x, B.y, B.z);
                gl.Vertex(F.x, F.y, F.z);
                gl.Vertex(E.x, E.y, E.z);

                gl.End();

                //sau
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(color.R / 285.0, color.G / 285.0, color.B / 285.0, 0.9);
                gl.Vertex(D.x, D.y, D.z);
                gl.Vertex(C.x, C.y, C.z);
                gl.Vertex(G.x, G.y, G.z);
                gl.Vertex(H.x, H.y, H.z);
                gl.End();

                //trái
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(color.R / 295.0, color.G / 295.0, color.B / 295.0, 0.9);
                gl.Vertex(B.x, B.y, B.z);
                gl.Vertex(C.x, C.y, C.z);
                gl.Vertex(G.x, G.y, G.z);
                gl.Vertex(F.x, F.y, F.z);
                gl.End();

                //phải
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(color.R / 305.0, color.G / 305.0, color.B / 305.0, 0.9);
                gl.Vertex(A.x, A.y, A.x);
                gl.Vertex(D.x, D.y, D.z);
                gl.Vertex(H.x, H.y, H.z);
                gl.Vertex(E.x, E.y, E.z);
                gl.End();
            }
            public override void scaledoituong(int sx,int sy,int sz)//su dung cho scale
            {
                A.x = Center.x + Radius * sx;
                A.y = Center.y + Radius * sy;
                A.z = Center.z + Radius * sz;

                B.x = Center.x + Radius * sx;
                B.y = Center.y - Radius * sy;
                B.z = Center.z + Radius * sz;

                C.x = Center.x - Radius * sx;
                C.y = Center.y - Radius * sy;
                C.z = Center.z + Radius * sz;

                D.x = Center.x - Radius * sx;
                D.y = Center.y + Radius * sy;
                D.z = Center.z + Radius * sz;

                E.x = Center.x + Radius * sx;
                E.y = Center.y + Radius * sy;
                E.z = Center.z - Radius * sz;

                F.x = Center.x + Radius * sx;
                F.y = Center.y - Radius * sy;
                F.z = Center.z - Radius * sz;

                G.x = Center.x - Radius * sx;
                G.y = Center.y - Radius * sy;
                G.z = Center.z - Radius * sz;

                H.x = Center.x - Radius * sx;
                H.y = Center.y + Radius * sy;
                H.z = Center.z - Radius * sz;
            }
            public  void xoaydiem(ref Point3d a,float gx,float gy,float gz)//xoay diem
            {
                float gocx,gocy,gocz;
                gocx = gx * (float)(3.14 / 180); 
                gocy = gy * (float)(3.14 / 180);
                gocz = gz * (float)(3.14 / 180);
                //xoay theo truc x
                a.z = (int)(a.z * Math.Cos(gocx) - a.y * Math.Sin(gocx));
                a.y = (int)(a.z * Math.Sin(gocx) + a.y * Math.Cos(gocx));
                //a.x = (int)a.x;
                //xoay theo truc y
                a.x = (int)(a.x * Math.Cos(gocy) - a.z * Math.Sin(gocy));
                a.z = (int)(a.x * Math.Sin(gocy) + a.z * Math.Cos(gocy));
                //a.y = (int)a.y;
                //xoay theo truc z
                a.x = (int)(a.x * Math.Cos(gocz) - a.y * Math.Sin(gocz));
                a.y = (int)(a.x * Math.Sin(gocz) + a.y * Math.Cos(gocz));
                //a.z = (int)a.z;
            }
            public override void xoaydoituong(float gx,float gy,float gz)//ve theo goc da xoay
            {                
                xoaydiem(ref this.A, gx, gy, gz);
                xoaydiem(ref this.B, gx, gy, gz);
                xoaydiem(ref this.C, gx, gy, gz);
                xoaydiem(ref this.D, gx, gy, gz);
                xoaydiem(ref this.E, gx, gy, gz);
                xoaydiem(ref this.F, gx, gy, gz);
                xoaydiem(ref this.G, gx, gy, gz);
                xoaydiem(ref this.H, gx, gy, gz);               
            }
            public override void viewControlPoint(OpenGL gl)
            {
                gl.LineWidth(10);
                gl.Begin(OpenGL.GL_LINE_LOOP);
                gl.Color(selectedColor.R / 255.0, selectedColor.G / 255.0, selectedColor.B / 255.0, 0);
                gl.Vertex(B.x, B.y, B.z);
                gl.Vertex(C.x, C.y, C.z);
                gl.Vertex(D.x, D.y, D.z);
                gl.Vertex(H.x, H.y, H.z);
                gl.Vertex(E.x, E.y, E.z);
                gl.Vertex(F.x, F.y, F.z);
                gl.End();
            }
        }

        public class Pyramid : Shape
        {
            public Point3d O, A, B, C, D;
            public Pyramid() : base()
            {
            }
            public override void initPoint()
            {
                A.x = Center.x + Radius; A.y = Center.y + Radius; A.z = Center.z - Radius;
                B.x = Center.x + Radius; B.y = Center.y - Radius; B.z = Center.z - Radius;
                C.x = Center.x - Radius; C.y = Center.y - Radius; C.z = Center.z - Radius;
                D.x = Center.x - Radius; D.y = Center.y + Radius; D.z = Center.z - Radius;

                O.x = Center.x; O.y = Center.y; O.z = Center.z + Radius;
            }

            public void xoaydiem(ref Point3d a, float gx, float gy, float gz)//xoay diem
            {
                float gocx, gocy, gocz;
                gocx = gx * (float)(3.14 / 180);
                gocy = gy * (float)(3.14 / 180);
                gocz = gz * (float)(3.14 / 180);
                //xoay theo truc x
                a.z = (int)(a.z * Math.Cos(gocx) - a.y * Math.Sin(gocx));
                a.y = (int)(a.z * Math.Sin(gocx) + a.y * Math.Cos(gocx));
                //a.x = (int)a.x;
                //xoay theo truc y
                a.x = (int)(a.x * Math.Cos(gocy) - a.z * Math.Sin(gocy));
                a.z = (int)(a.x * Math.Sin(gocy) + a.z * Math.Cos(gocy));
                //a.y = (int)a.y;
                //xoay theo truc z
                a.x = (int)(a.x * Math.Cos(gocz) - a.y * Math.Sin(gocz));
                a.y = (int)(a.x * Math.Sin(gocz) + a.y * Math.Cos(gocz));
                //a.z = (int)a.z;
            }
            public override void drawObject(OpenGL gl)
            {
               
                base.drawObject(gl);
                gl.Enable(OpenGL.GL_BLEND);
                gl.BlendFunc(OpenGL.GL_SRC_ALPHA, OpenGL.GL_ONE_MINUS_SRC_ALPHA);


                //đáy
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(color.R / 255.0, color.G / 255.0, color.B / 255.0, 0.9);
                gl.Vertex(A.x, A.y, A.z);
                gl.Vertex(B.x, B.y, B.z);
                gl.Vertex(C.x, C.y, C.z);
                gl.Vertex(D.x, D.y, D.z);
                gl.End();

                //trước
                gl.Begin(OpenGL.GL_POLYGON);
                gl.Color(color.R / 265.0, color.G / 265.0, color.B / 265.0, 0.9);
                gl.Vertex(A.x, A.y, A.z);
                gl.Vertex(B.x, B.y, B.z);
                gl.Vertex(O.x, O.y, O.z);
                gl.End();

                //sau
                gl.Begin(OpenGL.GL_POLYGON);
                gl.Color(color.R / 275.0, color.G / 275.0, color.B / 275.0, 0.9);
                gl.Vertex(C.x, C.y, C.z);
                gl.Vertex(D.x, D.y, D.z);
                gl.Vertex(O.x, O.y, O.z);
                gl.End();

                //trái
                gl.Begin(OpenGL.GL_POLYGON);
                gl.Color(color.R / 285.0, color.G / 285.0, color.B / 285.0, 0.9);
                gl.Vertex(B.x, B.y, B.z);
                gl.Vertex(C.x, C.y, C.z);
                gl.Vertex(O.x, O.y, O.z);
                gl.End();

                //phải
                gl.Begin(OpenGL.GL_POLYGON);
                gl.Color(color.R / 295.0, color.G / 295.0, color.B / 295.0, 0.9);
                gl.Vertex(D.x, D.y, D.z);
                gl.Vertex(A.x, A.y, A.z);
                gl.Vertex(O.x, O.y, O.z);
                gl.End();
            }
            public override void scaledoituong(int sx,int sy,int sz)
            {
                A.x = Center.x + Radius * sx; A.y = Center.y + Radius * sy; A.z = Center.z - Radius * sz;
                B.x = Center.x + Radius * sx; B.y = Center.y - Radius * sy; B.z = Center.z - Radius * sz;
                C.x = Center.x - Radius * sx; C.y = Center.y - Radius * sy; C.z = Center.z - Radius * sz;
                D.x = Center.x - Radius * sx; D.y = Center.y + Radius * sy; D.z = Center.z - Radius * sz;

                O.x = Center.x; O.y = Center.y; O.z = Center.z + Radius * sz;
            }
            public override void xoaydoituong( float gx, float gy, float gz)//ve theo goc cho trc
            {
               
                xoaydiem(ref this.O, gx, gy, gz);
                xoaydiem(ref this.A, gx, gy, gz);
                xoaydiem(ref this.B, gx, gy, gz);
                xoaydiem(ref this.C, gx, gy, gz);
                xoaydiem(ref this.D, gx, gy, gz);

                
            }
            public override void viewControlPoint(OpenGL gl)
            {
                gl.LineWidth(10);
                gl.Begin(OpenGL.GL_LINE_LOOP);
                gl.Color(selectedColor.R / 255.0, selectedColor.G / 255.0, selectedColor.B / 255.0, 0);

                gl.Vertex(A.x, A.y, A.z);
                gl.Vertex(D.x, D.y, D.z);
                gl.Vertex(O.x, O.y, O.z);
                gl.Vertex(B.x, B.y, B.z);

                gl.End();
            }
        }

        public class LangTru : Shape
        {
            public Point3d  A, B, C, D, E, F;
            public override void initPoint()
            {
                A.x = Center.x + Radius;
                A.y = Center.y;
                A.z = Center.z + Radius;
                B.x = Center.x - Radius;
                B.y = Center.y - Radius;
                B.z = Center.z + Radius;
                C.x = Center.x - Radius;
                C.y = Center.y + Radius;
                C.z = Center.z + Radius;
                D.x = Center.x + Radius;
                D.y = Center.y;
                D.z = Center.z - Radius;
                E.x = Center.x - Radius;
                E.y = Center.y - Radius;
                E.z = Center.z - Radius;
                F.x = Center.x - Radius;
                F.y = Center.y + Radius;
                F.z = Center.z - Radius;
            }

            public void xoaydiem(ref Point3d a, float gx, float gy, float gz)//xoay diem
            {
                float gocx, gocy, gocz;
                gocx = gx * (float)(3.14 / 180);
                gocy = gy * (float)(3.14 / 180);
                gocz = gz * (float)(3.14 / 180);
                //xoay theo truc x
                a.z = (int)(a.z * Math.Cos(gocx) - a.y * Math.Sin(gocx));
                a.y = (int)(a.z * Math.Sin(gocx) + a.y * Math.Cos(gocx));
                //a.x = (int)a.x;
                //xoay theo truc y
                a.x = (int)(a.x * Math.Cos(gocy) - a.z * Math.Sin(gocy));
                a.z = (int)(a.x * Math.Sin(gocy) + a.z * Math.Cos(gocy));
                //a.y = (int)a.y;
                //xoay theo truc z
                a.x = (int)(a.x * Math.Cos(gocz) - a.y * Math.Sin(gocz));
                a.y = (int)(a.x * Math.Sin(gocz) + a.y * Math.Cos(gocz));
                //a.z = (int)a.z;
            }
            public LangTru() : base()
            {
                Center.x = Center.y = Center.z = 0;
            }
            public override void drawObject(OpenGL gl)
            {
                gl.Enable(OpenGL.GL_BLEND);
                gl.BlendFunc(OpenGL.GL_SRC_ALPHA, OpenGL.GL_ONE_MINUS_SRC_ALPHA);

                //đỉnh
                gl.Begin(OpenGL.GL_POLYGON);
                gl.Color(color.R / 255.0, color.G / 255.0, color.B / 255.0, 1.0);
                gl.Vertex(A.x, A.y, A.z);
                gl.Vertex(B.x, B.y, B.z);
                gl.Vertex(C.x, C.y, C.z);
                gl.End();

                //đáy
                gl.Begin(OpenGL.GL_POLYGON);
                gl.Color(color.R / 265.0, color.G / 265.0, color.B / 265.0, 0.9);
                gl.Vertex(D.x, D.y, D.z);
                gl.Vertex(E.x, E.y, E.z);
                gl.Vertex(F.x, F.y, F.z);
                gl.End();

                //left
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(color.R / 275.0, color.G / 275.0, color.B / 275.0, 0.9);
                gl.Vertex(D.x, D.y, D.z );
                gl.Vertex(E.x , E.y , E.z );
                gl.Vertex(B.x, B.y , B.z );
                gl.Vertex(A.x , A.y, A.z );
                gl.End();

                //back
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(color.R / 285.0, color.G / 285.0, color.B / 285.0, 0.9);
                gl.Vertex(E.x , E.y , E.z );
                gl.Vertex(B.x , B.y , B.z );
                gl.Vertex(C.x , C.y , C.z );
                gl.Vertex(F.x , F.y , F.z );
                gl.End();

                //right
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(color.R / 295.0, color.G / 295.0, color.B / 295.0, 0.9);
                gl.Vertex(D.x , D.y, D.z );
                gl.Vertex(F.x , F.y , F.z );
                gl.Vertex(C.x, C.y , C.z );
                gl.Vertex(A.x , A.y, A.z );
                gl.End();
            }
            public override void scaledoituong(int sx,int sy,int sz)
            {
                A.x = Center.x + Radius * sx;
                A.y = Center.y;
                A.z = Center.z + Radius * sz;
                B.x = Center.x - Radius * sx;
                B.y = Center.y - Radius * sy;
                B.z = Center.z + Radius * sz;
                C.x = Center.x - Radius * sx;
                C.y = Center.y + Radius * sy;
                C.z = Center.z + Radius * sz;
                D.x = Center.x + Radius * sx;
                D.y = Center.y;
                D.z = Center.z - Radius * sz;
                E.x = Center.x - Radius * sx;
                E.y = Center.y - Radius * sy;
                E.z = Center.z - Radius * sz;
                F.x = Center.x - Radius * sx;
                F.y = Center.y + Radius * sy;
                F.z = Center.z - Radius * sz;
            }
            public override void xoaydoituong( float gx, float gy, float gz)
            {
               
                xoaydiem(ref this.A, gx, gy, gz);
                xoaydiem(ref this.B, gx, gy, gz);
                xoaydiem(ref this.C, gx, gy, gz);
                xoaydiem(ref this.D, gx, gy, gz);
                xoaydiem(ref this.E, gx, gy, gz);
                xoaydiem(ref this.F, gx, gy, gz);
                
            }
            public override void viewControlPoint(OpenGL gl)
            {
                gl.LineWidth(10);
                gl.Begin(OpenGL.GL_LINE_LOOP);
                gl.Color(selectedColor.R / 255.0, selectedColor.G / 255.0, selectedColor.B / 255.0, 0);

                gl.Vertex(D.x , D.y, D.z );
                gl.Vertex(A.x , A.y, A.z );
                gl.Vertex(B.x , B.y , B.z);
                gl.Vertex(C.x , C.y , C.z );
                gl.Vertex(F.x, F.y , F.z );
                gl.End();
            }
        }
        public class cubTexture : Shape
        {
            Texture textureObj;
            string filepath;

            public Point3d A, B, C, D, E, F, G, H;

            public cubTexture(OpenGL gl)
            {
                textureObj = new Texture();
                filepath = "Crate.bmp";
                //textureObj.Create(gl, filepath);
                //textureObj.Create(gl,filepath);
            }

            public void initPoint()
            {
                A.x = Center.x + Radius;
                A.y = Center.y + Radius;
                A.z = Center.z + Radius;

                B.x = Center.x + Radius;
                B.y = Center.y - Radius;
                B.z = Center.z + Radius;

                C.x = Center.x - Radius;
                C.y = Center.y - Radius;
                C.z = Center.z + Radius;

                D.x = Center.x - Radius;
                D.y = Center.y + Radius;
                D.z = Center.z + Radius;

                E.x = Center.x + Radius;
                E.y = Center.y + Radius;
                E.z = Center.z - Radius;

                F.x = Center.x + Radius;
                F.y = Center.y - Radius;
                F.z = Center.z - Radius;

                G.x = Center.x - Radius;
                G.y = Center.y - Radius;
                G.z = Center.z - Radius;

                H.x = Center.x - Radius;
                H.y = Center.y + Radius;
                H.z = Center.z - Radius;
            }

            public override void drawObject(OpenGL gl)
            {
                initPoint();
                base.drawObject(gl);
                gl.Enable(OpenGL.GL_TEXTURE_2D);
                //textureObj.Bind(gl);


                // đỉnh
                gl.Begin(OpenGL.GL_QUADS);//GL_QUADS là tứ giác
                gl.Color(1.0, 1.0, 1.0, 0.0);
                gl.TexCoord(0, 0);
                gl.Vertex(A.x, A.y, A.z);
                gl.TexCoord(1, 0);
                gl.Vertex(B.x, B.y, B.z);
                gl.TexCoord(1, 1);
                gl.Vertex(C.x, C.y, C.z);
                gl.TexCoord(0, 1);
                gl.Vertex(D.x, D.y, D.z);
                gl.End();

                //đáy

                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(1.0, 1.0, 1.0, 0.0);
                gl.TexCoord(0, 0);
                gl.Vertex(E.x, E.y, E.z);
                gl.TexCoord(1, 0);
                gl.Vertex(F.x, F.y, F.z);
                gl.TexCoord(1, 1);
                gl.Vertex(G.x, G.y, G.z);
                gl.TexCoord(0, 1);
                gl.Vertex(H.x, H.y, H.z);
                gl.End();

                // mặt trước

                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(1.0, 1.0, 1.0, 0.0);
                gl.TexCoord(0, 0);
                gl.Vertex(A.x, A.y, A.z);
                gl.TexCoord(1, 0);
                gl.Vertex(B.x, B.y, B.z);
                gl.TexCoord(1, 1);
                gl.Vertex(F.x, F.y, F.z);
                gl.TexCoord(0, 1);
                gl.Vertex(E.x, E.y, E.z);

                gl.End();

                //sau
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(1.0, 1.0, 1.0, 0.0);
                gl.TexCoord(0, 0);
                gl.Vertex(D.x, D.y, D.z);
                gl.TexCoord(1, 0);
                gl.Vertex(C.x, C.y, C.z);
                gl.TexCoord(1, 1);
                gl.Vertex(G.x, G.y, G.z);
                gl.TexCoord(0, 1);
                gl.Vertex(H.x, H.y, H.z);
                gl.End();

                //trái
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(1.0, 1.0, 1.0, 0.0);
                gl.TexCoord(0, 0);
                gl.Vertex(B.x, B.y, B.z);
                gl.TexCoord(1, 0);
                gl.Vertex(C.x, C.y, C.z);
                gl.TexCoord(1, 1);
                gl.Vertex(G.x, G.y, G.z);
                gl.TexCoord(0, 1);
                gl.Vertex(F.x, F.y, F.z);
                gl.End();

                //phải
                gl.Begin(OpenGL.GL_QUADS);
                gl.Color(1.0, 1.0, 1.0, 0.0);
                gl.TexCoord(0, 0);
                gl.Vertex(A.x, A.y, A.x);
                gl.TexCoord(1, 0);
                gl.Vertex(D.x, D.y, D.z);
                gl.TexCoord(1, 1);
                gl.Vertex(H.x, H.y, H.z);
                gl.TexCoord(0, 1);
                gl.Vertex(E.x, E.y, E.z);
                gl.End();
                gl.Disable(OpenGL.GL_TEXTURE_2D);
            }
            public override void viewControlPoint(OpenGL gl)
            {
                gl.LineWidth(10);
                gl.Begin(OpenGL.GL_LINE_LOOP);
                gl.Color(selectedColor.R / 255.0, selectedColor.G / 255.0, selectedColor.B / 255.0, 0);
                gl.Vertex(B.x, B.y, B.z);
                gl.Vertex(C.x, C.y, C.z);
                gl.Vertex(D.x, D.y, D.z);
                gl.Vertex(H.x, H.y, H.z);
                gl.Vertex(E.x, E.y, E.z);
                gl.Vertex(F.x, F.y, F.z);
                gl.End();
            }
        }

        //public class pyrTexture : Shape
        //{
        //    Texture textureObj;
        //    string filepath;

        //    public Point3d O, A, B, C, D;
        //    public pyrTexture(OpenGL gl)
        //    {
        //        textureObj = new Texture();
        //        filepath = "Crate.bmp";

        //        textureObj.Create(gl, filepath);

        //    }
        //    public void InitPoint()
        //    {
        //        A.x = Center.x + Radius; A.y = Center.y + Radius; A.z = Center.z - Radius;
        //        B.x = Center.x + Radius; B.y = Center.y - Radius; B.z = Center.z - Radius;
        //        C.x = Center.x - Radius; C.y = Center.y - Radius; C.z = Center.z - Radius;
        //        D.x = Center.x - Radius; D.y = Center.y + Radius; D.z = Center.z - Radius;

        //        O.x = Center.x; O.y = Center.y; O.z = Center.z + Radius;
        //    }
        //    public override void drawObject(OpenGL gl)
        //    {
        //        InitPoint();
        //        gl.Enable(OpenGL.GL_TEXTURE_2D);
        //        textureObj.Bind(gl);

        //        //đáy
        //        gl.Begin(OpenGL.GL_QUADS);
        //        gl.Color(1.0, 1.0, 1.0, 0.0);
        //        gl.TexCoord(0, 0);
        //        gl.Vertex(A.x, A.y, A.z);
        //        gl.TexCoord(1, 0);
        //        gl.Vertex(B.x, B.y, B.z);
        //        gl.TexCoord(1, 1);
        //        gl.Vertex(C.x, C.y, C.z);
        //        gl.TexCoord(0, 1);
        //        gl.Vertex(D.x, D.y, D.z);
        //        gl.End();

        //        //trước
        //        gl.Begin(OpenGL.GL_POLYGON);
        //        gl.Color(1.0, 1.0, 1.0, 0.0);
        //        gl.TexCoord(0, 0);
        //        gl.Vertex(A.x, A.y, A.z);
        //        gl.TexCoord(1, 0);
        //        gl.Vertex(B.x, B.y, B.z);
        //        gl.TexCoord(0.5, 1);
        //        gl.Vertex(O.x, O.y, O.z);
        //        gl.End();

        //        //sau
        //        gl.Begin(OpenGL.GL_POLYGON);
        //        gl.Color(1.0, 1.0, 1.0, 0.0);
        //        gl.TexCoord(0, 0);
        //        gl.Vertex(C.x, C.y, C.z);
        //        gl.TexCoord(1, 0);
        //        gl.Vertex(D.x, D.y, D.z);
        //        gl.TexCoord(0.5, 1);
        //        gl.Vertex(O.x, O.y, O.z);
        //        gl.End();

        //        //trái
        //        gl.Begin(OpenGL.GL_POLYGON);
        //        gl.Color(1.0, 1.0, 1.0, 0.0);
        //        gl.TexCoord(0, 0);
        //        gl.Vertex(B.x, B.y, B.z);
        //        gl.TexCoord(1, 0);
        //        gl.Vertex(C.x, C.y, C.z);
        //        gl.TexCoord(0.5, 1);
        //        gl.Vertex(O.x, O.y, O.z);
        //        gl.End();

        //        //phải
        //        gl.Begin(OpenGL.GL_POLYGON);
        //        gl.Color(1.0, 1.0, 1.0, 0.0);
        //        gl.TexCoord(0, 0);
        //        gl.Vertex(D.x, D.y, D.z);
        //        gl.TexCoord(1, 0);
        //        gl.Vertex(A.x, A.y, A.z);
        //        gl.TexCoord(0.5, 1);
        //        gl.Vertex(O.x, O.y, O.z);
        //        gl.End();
        //        gl.Disable(OpenGL.GL_TEXTURE_2D);
        //    }
        //    public override void viewControlPoint(OpenGL gl)
        //    {
        //        gl.LineWidth(10);
        //        gl.Begin(OpenGL.GL_LINE_LOOP);
        //        gl.Color(selectedColor.R / 255.0, selectedColor.G / 255.0, selectedColor.B / 255.0, 0);

        //        gl.Vertex(A.x, A.y, A.z);
        //        gl.Vertex(D.x, D.y, D.z);
        //        gl.Vertex(O.x, O.y, O.z);
        //        gl.Vertex(B.x, B.y, B.z);

        //        gl.End();
        //    }
        //}

        //private int numOfObject = 0;
        //private int numOfCube = 0;
        //private int numOfPyr = 0;
        //private int numOfPrism = 0;
        //private int numOfCubeTex = 0;
        //private int numOfPyrTex = 0;

        Shape[] object3D = new Shape[100];
        private Point3d pointControl;
        private int bankinh = 2;
 //       Camera camera;
        bool vekhonggian;
        Color userColor = Color.White;
        int idViewPoint = -1;

        private void openGLControl_Click(object sender, EventArgs e)
        {

        }
        private void openGLControl_Load(object sender, EventArgs e)
        {

        }


        private void openGLControl_OpenGLInitialized(object sender, EventArgs e)
        {
            OpenGL gl = openGLControl.OpenGL;
            gl.ClearColor(0, 0, 0, 0);
    //        camera = new Camera();
            vekhonggian = false;
        }
        private void openGLControl_Resize(object sender, EventArgs e)
        {
            OpenGL gl = openGLControl.OpenGL;
            
            //set ma tran viewport
            gl.Viewport(
                0, 0,
                openGLControl.Width,
                openGLControl.Height);

            //set ma tran phep chieu
            gl.MatrixMode(OpenGL.GL_PROJECTION);
            gl.Perspective(60, openGLControl.Width / openGLControl.Height, 1.0, 10000.0);
            //gl.LoadIdentity();
            gl.MatrixMode(OpenGL.GL_MODELVIEW);
            gl.LookAt(cam.camera_posX, cam.camera_posY, cam.camera_posZ, cam.cenX, cam.cenY, cam.cenZ, cam.upX, cam.upY, cam.upZ);
            
        }

     

        private void openGLControl_OpenGLDraw(object sender, SharpGL.RenderEventArgs args)
        {
            OpenGL gl = openGLControl.OpenGL;

            gl.MatrixMode(OpenGL.GL_MODELVIEW);
            gl.LoadIdentity();
            gl.LookAt(cam.camera_posX, cam.camera_posY, cam.camera_posZ, cam.cenX, cam.cenY, cam.cenZ, cam.upX, cam.upY, cam.upZ);

            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            Vekhungcanh(gl);
            if (nendich==0&&nenzoom==0&&nenxoay==0)
            {
                
                if (shShape == 1)
                {
                    object3D[doituong] = new cube();
                    object3D[doituong].Set(pointControl, bankinh);
                    object3D[doituong].SetColor(userColor);
                    object3D[doituong].initPoint();
                    object3D[doituong].drawObject(gl);
                    
                }
                else if (shShape == 2)
                {
                    object3D[doituong] = new Pyramid();
                    object3D[doituong].Set(pointControl, bankinh);
                    object3D[doituong].SetColor(userColor);
                    object3D[doituong].initPoint();
                    object3D[doituong].drawObject(gl);
                   
                }
                else if (shShape == 3)
                {
                    object3D[doituong] = new LangTru();
                    object3D[doituong].Set(pointControl, bankinh);
                    object3D[doituong].SetColor(userColor);
                    object3D[doituong].initPoint();
                    object3D[doituong].drawObject(gl);
                    
                }
                else if (shShape == 4)
                {

                    
                }               
            }
           
            if(nendich==1)
            {

               
                object3D[doituong].Set(tamdich, bankinh);
                object3D[doituong].SetColor(userColor);
                object3D[doituong].initPoint();
                object3D[doituong].drawObject(gl);
                
                
            }
            if(nenzoom==1)
            {

                object3D[doituong].initPoint();
                object3D[doituong].scaledoituong(scalex,scaley,scalez);
                object3D[doituong].drawObject(gl);
            }
            if (nenxoay == 1)
            {
                object3D[doituong].initPoint();
                object3D[doituong].xoaydoituong( xoayx, xoayy, xoayz);
                object3D[doituong].drawObject(gl);
            }
            gl.Flush();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)  //xữ lý nhập key từ bàn phím
        {
            OpenGL gl = openGLControl.OpenGL;

            if (keyData == Keys.Up)         //di chuyển camera lên trên nhấn mũi tên lên trên
            {
                
                cam.RotateUp();
                gl.LoadIdentity();


                gl.LookAt(
                   cam.camera_posX, cam.camera_posY, cam.camera_posZ,   //hàm xác định vị trí camera
                   cam.cenX, cam.cenY, cam.cenZ,
                   cam.upX, cam.upY, cam.upZ);

                return true;
            }
            else if (keyData == Keys.Down)  //di chuyển camera xuống dưới mũi tên xuống
            {
               
                cam.RotateDow();
                gl.LoadIdentity();

                gl.LookAt(
                   cam.camera_posX, cam.camera_posY, cam.camera_posZ,
                   cam.cenX, cam.cenY, cam.cenZ,
                   cam.upX, cam.upY, cam.upZ);
                return true;
            }
            else if (keyData == Keys.Z)     //Di chuyển camera lại gần nhấn phím Z
            {
              
                cam.ZoomIn();
                gl.LoadIdentity();

                gl.LookAt(
                   cam.camera_posX, cam.camera_posY, cam.camera_posZ,
                   cam.cenX, cam.cenY, cam.cenZ,
                   cam.upX, cam.upY, cam.upZ);
                return true;
            }
            else if (keyData == Keys.X)     //di chuyển camera ra xa nhấn phím X
            {
               
                cam.ZoomOut();
                gl.LoadIdentity();

                gl.LookAt(
                   cam.camera_posX, cam.camera_posY, cam.camera_posZ,
                   cam.cenX, cam.cenY, cam.cenZ,
                   cam.upX, cam.upY, cam.upZ);
                return true;
            }
            else if (keyData == Keys.Left) //di chuyển camera sang trái nhấn phím mủi tên trái
            {
               
                cam.RotateLeft();
                gl.LoadIdentity();

                gl.LookAt(
                   cam.camera_posX, cam.camera_posY, cam.camera_posZ,
                   cam.cenX, cam.cenY, cam.cenZ,
                   cam.upX, cam.upY, cam.upZ);

                return true;
            }
            else if (keyData == Keys.Right)     //di chuyển camera sang phải nhấn phím mủi tên phải
            {
               
                cam.RotateRight();

                gl.LoadIdentity();

                gl.LookAt(
                   cam.camera_posX, cam.camera_posY, cam.camera_posZ,
                   cam.cenX, cam.cenY, cam.cenZ,
                   cam.upX, cam.upY, cam.upZ);
                return true;
            }


            return base.ProcessCmdKey(ref msg, keyData);
        }
        private void Vekhungcanh(OpenGL gl)
        {
            gl.LineWidth(0.5f); //nét mỏng
            int size = 8;
            for (int i = 0; i < size; i++)
            {
                gl.Begin(OpenGL.GL_LINES);  //vẽ các đường thẳng
                gl.Color(1.0, 1.0, 1.0, 1.0);
                gl.Vertex(size, i, 0);
                gl.Vertex(-size, i, 0);
                gl.End();

                gl.Begin(OpenGL.GL_LINES);
                gl.Color(1.0, 1.0, 1.0, 1.0);
                gl.Vertex(size, -i, 0);
                gl.Vertex(-size, -i, 0);
                gl.End();
            }

            for (int i = 1; i <= size; i++) //vẽ các đường thẳng
            {
                gl.Begin(OpenGL.GL_LINES);
                gl.Color(1.0, 1.0, 1.0, 1.0);
                gl.Vertex(i, size, 0);
                gl.Vertex(i, -size, 0);
                gl.End();

                gl.Begin(OpenGL.GL_LINES);
                gl.Color(1.0, 1.0, 1.0, 1.0);
                gl.Vertex(-i, size, 0);
                gl.Vertex(-i, -size, 0);
                gl.End();
            }

            gl.LineWidth(2);  //độ dày nét vẽ
            gl.Begin(OpenGL.GL_LINES); // vẽ các trục tọa độ
            gl.Color(1.0, 0.0, 0.0, 1.0);
            gl.Vertex(0, 0, size);      //trục Z
            gl.Vertex(0, 0, -size);
            gl.End();

            gl.Begin(OpenGL.GL_LINES);
            gl.Color(0.0, 1.0, 0.0, 1.0);
            gl.Vertex(0, size, 0);        //trục Y
            gl.Vertex(0, -size, 0);
            gl.End();

            gl.Begin(OpenGL.GL_LINES);
            gl.Color(0.0, 0.0, 1.0, 1.0);       //trục X
            gl.Vertex(size, 0, 0);
            gl.Vertex(-size, 0, 0);
            gl.End();
        }
        private void bt_cube_Click(object sender, EventArgs e)
        {
            nenxoay = 0;
            nenzoom = 0;
            nendich = 0;
            shShape = 1;
            listView1.Items.Add("Cube ");
        }

        private void bt_Pyramid_Click(object sender, EventArgs e)
        {
            nenxoay = 0;
            nenzoom = 0;
            nendich = 0;
            shShape = 2;
            listView1.Items.Add("Pyramid ");
        }

        private void BT_langtru_Click(object sender, EventArgs e)
        {
            nenxoay = 0;
            nenzoom = 0;
            nendich = 0;
            shShape = 3;
            listView1.Items.Add("Lang tru  " );
        }

        private void bt_color_Click(object sender, EventArgs e)
        {
            if(colorDialog1.ShowDialog()==DialogResult.OK)
            {
                userColor = colorDialog1.Color;
            }
        }

        private void bt_pyramidTexture_Click(object sender, EventArgs e)
        {
            shShape = 4;
        }

        private void bt_dich_Click(object sender, EventArgs e)
        {
            
            nendich = 1;
            nenxoay = 0;
            
            tamdich.x = int.Parse(dichx);
            tamdich.y = int.Parse(dichy);
            tamdich.z = int.Parse(dichz);
        }

        private void tb_dichX_TextChanged(object sender, EventArgs e)
        {
            dichx = tb_dichX.Text;
        }

        private void tb_dichY_TextChanged(object sender, EventArgs e)
        {
            dichy = tb_dichY.Text;
        }

        private void tb_dichZ_TextChanged(object sender, EventArgs e)
        {
            dichz = tb_dichZ.Text;
        }

        private void bt_scale_Click(object sender, EventArgs e)
        {
            nenzoom = 1;
            scalex = int.Parse(zoomx);
            scaley = int.Parse(zoomy);
            scalez = int.Parse(zoomz);
        }

        private void tb_scaleX_TextChanged(object sender, EventArgs e)
        {
            zoomx = tb_scaleX.Text;
           
        }

        

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                listView1.Items[i].Font = new Font(listView1.Font, FontStyle.Regular);
                ListViewItem item = listView1.Items[i];
                Rectangle itemRect = item.GetBounds(ItemBoundsPortion.Label);
                if (itemRect.Contains(e.Location))
                {
                    idViewPoint = i + 1;
                    listView1.Items[i].Font = new Font(listView1.Font, FontStyle.Bold);
                }
            }
        }

        private void tb_bankinh_TextChanged(object sender, EventArgs e)
        {
            string bk = tb_bankinh.Text;
            bankinh = int.Parse(bk);
        }

        private void bt_xoay_Click(object sender, EventArgs e)//xoay
        {
            nenxoay = 1;
            nendich = 0;

            xoayx = float.Parse(rotationx);
            xoayy = float.Parse(rotationy);
            xoayz = float.Parse(rotationz);
        }

        private void tb_xoayy_TextChanged(object sender, EventArgs e)//do xoay y
        {
            rotationy = tb_xoayy.Text;
        }

        private void tb_xoayx_TextChanged(object sender, EventArgs e)//do xoay x
        {
            rotationx = tb_xoayx.Text;
        }

        private void tb_xoayz_TextChanged(object sender, EventArgs e)// do xoay z
        {
            rotationz = tb_xoayz.Text;
        }

        private void tb_scalez_TextChanged(object sender, EventArgs e)//do scale z
        {
            zoomz = tb_scalez.Text;
        }

        private void tb_scaley_TextChanged(object sender, EventArgs e)
        {
            zoomy = tb_scaley.Text;
        }

    }
}
