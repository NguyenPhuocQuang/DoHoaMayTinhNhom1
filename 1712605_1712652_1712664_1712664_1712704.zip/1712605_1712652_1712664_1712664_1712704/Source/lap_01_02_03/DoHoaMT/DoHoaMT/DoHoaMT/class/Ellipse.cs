﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using SharpGL;

namespace DoHoaMT.ClassEllipse
{
    public class eclipse
    {
        private Point Startpoint;
        private Point Endpoint;

        public void Veeclipse(Point pStart, Point pEnd, OpenGL gl)
        {

            int Rx, Ry;
            Rx = (int)Math.Abs((pEnd.X - pStart.X)) / 2;
            Ry = (int)Math.Abs(pEnd.Y - pStart.Y) / 2;

            int xc, yc;
            xc = (pEnd.X + pStart.X) / 2;//toa do tam
            yc = (pStart.Y + pEnd.Y) / 2;

            yc = gl.RenderContextProvider.Height - yc;

            int x0, y0;
            x0 = 0;
            y0 = Ry;

            int rry2x0, rrx2y0, p10;//cac hang so
            rry2x0 = 2 * Ry * Ry * x0;
            rrx2y0 = 2 * Rx * Rx * y0;
            p10 = Ry * Ry - Rx * Rx * Ry + (1 / 4) * Rx * Rx;

            gl.Vertex(xc + x0, yc + y0);
            gl.Vertex(xc - x0, yc + y0);
            gl.Vertex(xc + x0, yc - y0);
            gl.Vertex(xc - x0, yc - y0);

            for (int k = 0; rry2x0 < rrx2y0; k++)
            {
                if (p10 < 0)
                {
                    x0++;
                    rry2x0 += 2 * Ry * Ry;
                    p10 += rry2x0 + Ry * Ry;
                }
                else if (p10 >= 0)
                {
                    x0++;
                    y0--;
                    rry2x0 += 2 * Ry * Ry;
                    rrx2y0 -= 2 * Rx * Rx;
                    p10 += rry2x0 - rrx2y0 + Ry * Ry;
                }

                gl.Vertex(xc + x0, yc + y0);//ve va tinh tien cac dinh
                gl.Vertex(xc - x0, yc + y0);
                gl.Vertex(xc + x0, yc - y0);
                gl.Vertex(xc - x0, yc - y0);
            }

            int Xlast, Ylast;
            Xlast = x0;
            Ylast = y0;
            int rrx2Ylast, rry2Xlast, p20;
            rrx2Ylast = 2 * Rx * Rx * Ylast;
            rry2Xlast = 2 * Ry * Ry * Xlast;
            p20 = Ry * Ry * (Xlast + 1 / 2) * (Xlast + 1 / 2) + Rx * Rx * (Ylast - 1) * (Ylast - 1) - Rx * Rx * Ry * Ry;

            for (int k = 0; y0 != 0; k++)
            {
                if (p20 > 0)
                {
                    y0--;
                    rrx2Ylast -= 2 * Rx * Rx;
                    p20 += Rx * Rx - rrx2Ylast;
                }
                else
                {
                    x0++;
                    y0--;
                    rry2Xlast += 2 * Ry * Ry;
                    rrx2Ylast -= 2 * Rx * Rx;
                    p20 += rry2Xlast - rrx2Ylast + Rx * Rx;
                }

                gl.Vertex(xc + x0, yc + y0);//ve va tinh tien cac dinh
                gl.Vertex(xc - x0, yc + y0);
                gl.Vertex(xc + x0, yc - y0);
                gl.Vertex(xc - x0, yc - y0);
            }

            gl.End();
            gl.Flush();// Thực hiện lệnh vẽ ngay lập tức thay vì đợi sau 1 khoảng thời gian
        }
    }
}
