﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SharpGL;

namespace Demo.ClassCameara
{
    class Camera
    {
        public double camera_posX, camera_posY, camera_posZ; //vị trí camera
        private double camera_frontX, camera_frontY, camera_frontZ; //vector chỉ hướng của camera
        public double cenX, cenY, cenZ; //điểm camera nhìn
        public double upX, upY, upZ; //vector up của camera
        private double radius, alpha, theta, speed;

        public Camera()
        {
            camera_posX = 5;
            camera_posY = 7;
            camera_posZ = 6;
            cenX = 0;
            cenY = 0;
            cenZ = 0;
            upX = 0;
            upY = 1;
            upZ = 0;
            radius = 5;
            alpha = Math.PI / 180;
            theta = Math.PI / 180;
            speed = 0.005;
            camera_frontX = camera_posX - cenX;
            camera_frontY = camera_posY - cenY;
            camera_frontZ = camera_posZ - cenZ;
        }

        public void Calculate() //tính vector chỉ hướng nhìn của camera
        {

            camera_frontX = camera_posX - cenX;
            camera_frontY = camera_posY - cenY;
            camera_frontZ = camera_posZ - cenZ;

        }



        public void ZoomIn()   //lại gần vật
        {

            camera_posX += speed * -camera_frontX; //tính tọa độ camera
            camera_posY += speed * -camera_frontY;
            camera_posZ += speed * -camera_frontZ;
            Calculate();
        }

        public void ZoomOut()  //ra xa vật
        {
            camera_posX += speed * camera_posX;  //tính tọa độ camera
            camera_posY += speed * camera_posY;
            camera_posZ += speed * camera_posZ;
            Calculate();
        }

        public void RotateRight()  //xoay sung quanh vật qua phải
        {
            camera_posX = camera_frontZ * Math.Sin(theta) + camera_frontX * Math.Cos(theta) + cenX; //tính tọa độ dựa trên phép xoay
            camera_posZ = camera_frontZ * Math.Cos(theta) - camera_frontX * Math.Sin(theta) + cenZ;
            upX = upZ * Math.Sin(theta) + upX * Math.Cos(theta);
            upZ = upZ * Math.Cos(theta) - upX * Math.Sin(theta);

            Calculate();
        }

        public void RotateLeft()   //xoay sung quanh vật qua trái
        {
            camera_posX = camera_frontZ * Math.Sin(-theta) + camera_frontX * Math.Cos(-theta) + cenX; //tính tọa độ điểm đặc camera dựa trên phép xoay
            camera_posZ = camera_frontZ * Math.Cos(-theta) - camera_frontX * Math.Sin(-theta) + cenZ;

            upX = upZ * Math.Sin(-theta) + upX * Math.Cos(-theta);
            upZ = upZ * Math.Cos(-theta) - upX * Math.Sin(-theta);

            Calculate();
        }

        public void RotateUp()         //xoay sung quanh vật lên trên
        {

            //xoay theo truc x
            camera_posZ = (int)(camera_posZ * Math.Cos(theta) - camera_posY * Math.Sin(theta));
            camera_posY = (int)(camera_posZ * Math.Sin(theta) + camera_posY * Math.Cos(theta));

            //xoay theo truc y
            camera_posX = (int)(camera_posX * Math.Cos(theta) - camera_posZ * Math.Sin(theta));
            camera_posZ = (int)(camera_posX * Math.Sin(theta) + camera_posZ * Math.Cos(theta));

            //xoay theo truc z
            camera_posX = (int)(camera_posX * Math.Cos(theta) - camera_posY * Math.Sin(theta));
            camera_posY = (int)(camera_posX * Math.Sin(theta) + camera_posY * Math.Cos(theta));

            Calculate();

            //upZ = (int)(upZ * Math.Cos(theta) - upY * Math.Sin(theta));
            //upY = (int)(upZ * Math.Sin(theta) + upY * Math.Cos(theta));

            ////xoay theo truc y
            //upX = (int)(upX * Math.Cos(theta) - upZ * Math.Sin(theta));
            //upZ = (int)(upX * Math.Sin(theta) + upZ * Math.Cos(theta));

            ////xoay theo truc z
            //upX = (int)(upX * Math.Cos(theta) - upY * Math.Sin(theta));
            //upY = (int)(upX * Math.Sin(theta) + upY * Math.Cos(theta));
        }

        public void RotateDow()            //xoay sung quanh vật xuống dưới
        {

        }


    }
}
