﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpGL;
using System.Drawing;

namespace DoHoaMT.ClassDuongThang
{
    public class duongthang
    {
        private Point Startpoint;
        private Point Endpoint;

        public void Veduongthang(Point pStart, Point pEnd, OpenGL gl)
        {
            int x, y, dx, dy, p;
            int const1, const2;
            x = pStart.X;
            y = gl.RenderContextProvider.Height - pStart.Y;
            dx = pEnd.X - pStart.X;
            dy = gl.RenderContextProvider.Height - pEnd.Y - y;
            p = 2 * dy - dx;
            const1 = 2 * dy;
            const2 = 2 * (dy - dx);
            float m = 99999;
            if (dx != 0)
                m = (float)dy / dx;
            int steps;
            if (Math.Abs(dx) >= Math.Abs(dy))
                steps = Math.Abs(dx);
            else
                steps = Math.Abs(dy);

            gl.Begin(OpenGL.GL_POINTS);////////////////////////////////////////////

            gl.Vertex(x, y);//ve diem dau
            if (m > 0 && m < 1)
            {
                if (x < pEnd.X)// TH ve tu duoi len tu tai sang phai
                {
                    for (int k = 0; k < steps; k++)
                    {
                        if (p < 0)
                        {
                            gl.Vertex(x + 1, y);
                            x++;
                            p += const1;
                        }
                        else
                        {
                            gl.Vertex(x + 1, y + 1);
                            x++;
                            y++;
                            p += const2;
                        }
                    }
                }
                else if (x > pEnd.X)// TH ve tu tren xuong tu phai sang tai
                {
                    for (int k = 0; k < steps; k++)
                    {
                        if (p < 0)
                        {
                            gl.Vertex(x - 1, y);
                            x--;
                            
                            p -= const1;
                        }
                        else
                        {
                            gl.Vertex(x - 1, y - 1);
                            y--;
                            x--;
                            p -= const2;
                        }
                    }
                }
            }
            else if (m >= 1 && x != pEnd.X)///
            {

                float x2 = x;
                if (x < pEnd.X)
                {
                    for (int k = 0; k < steps; k++)
                    {
                        x2 += 1 / m;
                        gl.Vertex(Math.Round(x2), y + 1);
                        y++;

                    }
                }
                else if (x > pEnd.X)
                {
                    for (int k = 0; k < steps; k++)
                    {
                        x2 -= 1 / m;
                        gl.Vertex(Math.Round(x2), y + 1);
                        y--;

                    }
                }

            }
            else if (pStart.X == pEnd.X && pStart.Y != pEnd.Y)//duong thang dung
            {
                if (y < gl.RenderContextProvider.Height - pEnd.Y)
                {
                    for (int k = 0; k < steps - 1; k++)///////////////////
                    {
                        gl.Vertex(x, y + 1);
                       
                        y++;
                    }
                }
                else if (y > gl.RenderContextProvider.Height - pEnd.Y)
                {
                    for (int k = 0; k < steps - 1; k++)////////////////////
                    {
                        gl.Vertex(x, y - 1);
                        y--;
                    }
                }

            }
            else if (m == 0)//ve duong nam ngang
            {
                if (x < pEnd.X)
                {
                    for (int k = 0; k < steps; k++)
                    {
                        gl.Vertex(x + 1, y);
                        x++;
                    }
                }
                else if (x > pEnd.X)
                {
                    for (int k = 0; k < steps; k++)
                    {
                        gl.Vertex(x - 1, y);
                        x--;
                    }
                }

            }
            else if (Math.Abs(m) < 1)///////////////ve duong xien tu trai qua phai va khong doc
            {
                float y3 = y;
                if (x < pEnd.X)
                {
                    for (int k = 0; k < steps; k++)
                    {
                        y3 -= Math.Abs(m);
                        gl.Vertex(x + 1, Math.Round(y3));
                        x++;
                    }
                }
                else if (x > pEnd.X)
                {
                    for (int k = 0; k < steps; k++)
                    {
                        y3 += Math.Abs(m);
                        gl.Vertex(x - 1, Math.Round(y3));
                        x--;
                    }
                }

            }
            else if (Math.Abs(m) > 1 && m < 0)
            {
                float x4 = x;
                if (x < pEnd.X)
                {
                    for (int k = 0; k < steps; k++)
                    {
                        x4 += 1 / Math.Abs(m);
                        gl.Vertex(Math.Round(x4), y - 1);
                        y--;
                    }
                }
                else if (x > pEnd.X)
                {
                    for (int k = 0; k < steps; k++)
                    {
                        x4 -= 1 / Math.Abs(m);
                        gl.Vertex(Math.Round(x4), y + 1);
                        y++;
                    }
                }
            }
            gl.End();
            gl.Flush();
        }

    }
}
