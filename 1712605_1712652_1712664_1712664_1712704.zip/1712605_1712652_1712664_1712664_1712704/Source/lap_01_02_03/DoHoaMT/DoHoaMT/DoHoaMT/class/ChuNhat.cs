﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using SharpGL;
using DoHoaMT.ClassDuongThang;

namespace DoHoaMT.ClassChuNhat
{
   public class ChuNhat
    {
        

        public void VeHinhChuNHat(Point pStart, Point pEnd, OpenGL gl)
        {
            //xac dinh cac diem can ve
            Point p1 = new Point(pStart.X, pStart.Y);

            Point p3 = new Point(pEnd.X, pEnd.Y);// diem thu 3

            Point p2 = new Point(pEnd.X, pStart.Y);// diem thu 2

            Point p4 = new Point(pStart.X, pEnd.Y);// diem thu 4

            duongthang dt3 = new duongthang();
            dt3.Veduongthang(p4, p3, gl);

            duongthang dt1 = new duongthang(); //lan luoc ve cac canh
            dt1.Veduongthang(p4, p1, gl);

            duongthang dt4 = new duongthang();
            dt4.Veduongthang(p3, p2, gl);

            duongthang dt2 = new duongthang();
            dt2.Veduongthang(p1, p2, gl);
        }
    }
}
