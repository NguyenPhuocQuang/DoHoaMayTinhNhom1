﻿namespace DoHoaMT
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openGLControl = new SharpGL.OpenGLControl();
            this.bt_Line = new System.Windows.Forms.Button();
            this.bt_BangMau = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.bt_Circle = new System.Windows.Forms.Button();
            this.bt_Ellipse = new System.Windows.Forms.Button();
            this.bt_Rectangle = new System.Windows.Forms.Button();
            this.bt_Triangle = new System.Windows.Forms.Button();
            this.bt_Pentagonal = new System.Windows.Forms.Button();
            this.bt_Hexagon = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.txb_Time = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.bt_truotx = new System.Windows.Forms.Button();
            this.bt_truoty = new System.Windows.Forms.Button();
            this.nud_dtx = new System.Windows.Forms.NumericUpDown();
            this.nud_dty = new System.Windows.Forms.NumericUpDown();
            this.tinhtienx = new System.Windows.Forms.Button();
            this.tinhtieny = new System.Windows.Forms.Button();
            this.tb_ttx = new System.Windows.Forms.TextBox();
            this.tb_tty = new System.Windows.Forms.TextBox();
            this.bt_Quay = new System.Windows.Forms.Button();
            this.tb_Quay = new System.Windows.Forms.TextBox();
            this.bt_cogian = new System.Windows.Forms.Button();
            this.nud_cogian = new System.Windows.Forms.NumericUpDown();
            this.bt_dxox = new System.Windows.Forms.Button();
            this.bt_dxoy = new System.Windows.Forms.Button();
            this.bt_DaGiac = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dtx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_cogian)).BeginInit();
            this.SuspendLayout();
            // 
            // openGLControl
            // 
            this.openGLControl.DrawFPS = false;
            this.openGLControl.Location = new System.Drawing.Point(12, 108);
            this.openGLControl.Name = "openGLControl";
            this.openGLControl.OpenGLVersion = SharpGL.Version.OpenGLVersion.OpenGL2_1;
            this.openGLControl.RenderContextType = SharpGL.RenderContextType.DIBSection;
            this.openGLControl.RenderTrigger = SharpGL.RenderTrigger.TimerBased;
            this.openGLControl.Size = new System.Drawing.Size(776, 339);
            this.openGLControl.TabIndex = 0;
            this.openGLControl.OpenGLInitialized += new System.EventHandler(this.openGLControl_OpenGLInitialized);
            this.openGLControl.OpenGLDraw += new SharpGL.RenderEventHandler(this.openGLControl_OpenGLDraw);
            this.openGLControl.Resized += new System.EventHandler(this.openGLControl_Resized);
            this.openGLControl.Load += new System.EventHandler(this.openGLControl_Load);
            this.openGLControl.MouseClick += new System.Windows.Forms.MouseEventHandler(this.openGLControl_MouseClick);
            this.openGLControl.MouseDown += new System.Windows.Forms.MouseEventHandler(this.openGLControl_MouseDown);
            this.openGLControl.MouseMove += new System.Windows.Forms.MouseEventHandler(this.openGLControl_MouseMove);
            this.openGLControl.MouseUp += new System.Windows.Forms.MouseEventHandler(this.openGLControl_MouseUp);
            // 
            // bt_Line
            // 
            this.bt_Line.Location = new System.Drawing.Point(12, 12);
            this.bt_Line.Name = "bt_Line";
            this.bt_Line.Size = new System.Drawing.Size(75, 23);
            this.bt_Line.TabIndex = 1;
            this.bt_Line.Text = "Line";
            this.bt_Line.UseVisualStyleBackColor = true;
            this.bt_Line.Click += new System.EventHandler(this.bt_Line_Click);
            // 
            // bt_BangMau
            // 
            this.bt_BangMau.Location = new System.Drawing.Point(579, 13);
            this.bt_BangMau.Name = "bt_BangMau";
            this.bt_BangMau.Size = new System.Drawing.Size(75, 23);
            this.bt_BangMau.TabIndex = 2;
            this.bt_BangMau.Text = "Bang Mau";
            this.bt_BangMau.UseVisualStyleBackColor = true;
            this.bt_BangMau.Click += new System.EventHandler(this.bt_BangMau_Click);
            // 
            // bt_Circle
            // 
            this.bt_Circle.Location = new System.Drawing.Point(93, 13);
            this.bt_Circle.Name = "bt_Circle";
            this.bt_Circle.Size = new System.Drawing.Size(75, 23);
            this.bt_Circle.TabIndex = 3;
            this.bt_Circle.Text = "Circle";
            this.bt_Circle.UseVisualStyleBackColor = true;
            this.bt_Circle.Click += new System.EventHandler(this.bt_Circle_Click);
            // 
            // bt_Ellipse
            // 
            this.bt_Ellipse.Location = new System.Drawing.Point(498, 13);
            this.bt_Ellipse.Name = "bt_Ellipse";
            this.bt_Ellipse.Size = new System.Drawing.Size(75, 23);
            this.bt_Ellipse.TabIndex = 4;
            this.bt_Ellipse.Text = "Ellipse";
            this.bt_Ellipse.UseVisualStyleBackColor = true;
            this.bt_Ellipse.Click += new System.EventHandler(this.bt_Ellipse_Click);
            // 
            // bt_Rectangle
            // 
            this.bt_Rectangle.Location = new System.Drawing.Point(174, 13);
            this.bt_Rectangle.Name = "bt_Rectangle";
            this.bt_Rectangle.Size = new System.Drawing.Size(75, 23);
            this.bt_Rectangle.TabIndex = 5;
            this.bt_Rectangle.Text = "Rectangle";
            this.bt_Rectangle.UseVisualStyleBackColor = true;
            this.bt_Rectangle.Click += new System.EventHandler(this.bt_Rectangle_Click);
            // 
            // bt_Triangle
            // 
            this.bt_Triangle.Location = new System.Drawing.Point(255, 13);
            this.bt_Triangle.Name = "bt_Triangle";
            this.bt_Triangle.Size = new System.Drawing.Size(75, 23);
            this.bt_Triangle.TabIndex = 6;
            this.bt_Triangle.Text = "Triangle";
            this.bt_Triangle.UseVisualStyleBackColor = true;
            this.bt_Triangle.Click += new System.EventHandler(this.bt_Triangle_Click);
            // 
            // bt_Pentagonal
            // 
            this.bt_Pentagonal.Location = new System.Drawing.Point(336, 13);
            this.bt_Pentagonal.Name = "bt_Pentagonal";
            this.bt_Pentagonal.Size = new System.Drawing.Size(75, 23);
            this.bt_Pentagonal.TabIndex = 7;
            this.bt_Pentagonal.Text = "Pentagonal";
            this.bt_Pentagonal.UseVisualStyleBackColor = true;
            this.bt_Pentagonal.Click += new System.EventHandler(this.bt_Pentagonal_Click);
            // 
            // bt_Hexagon
            // 
            this.bt_Hexagon.Location = new System.Drawing.Point(417, 13);
            this.bt_Hexagon.Name = "bt_Hexagon";
            this.bt_Hexagon.Size = new System.Drawing.Size(75, 23);
            this.bt_Hexagon.TabIndex = 8;
            this.bt_Hexagon.Text = "Hexagon";
            this.bt_Hexagon.UseVisualStyleBackColor = true;
            this.bt_Hexagon.Click += new System.EventHandler(this.bt_Hexagon_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(713, 12);
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(75, 20);
            this.numericUpDown1.TabIndex = 9;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // txb_Time
            // 
            this.txb_Time.Location = new System.Drawing.Point(750, 41);
            this.txb_Time.Name = "txb_Time";
            this.txb_Time.ReadOnly = true;
            this.txb_Time.Size = new System.Drawing.Size(33, 20);
            this.txb_Time.TabIndex = 11;
            this.txb_Time.TextChanged += new System.EventHandler(this.txb_Time_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(624, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Thời gian thực hiện:(ms)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(680, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Size";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // bt_truotx
            // 
            this.bt_truotx.Location = new System.Drawing.Point(12, 42);
            this.bt_truotx.Name = "bt_truotx";
            this.bt_truotx.Size = new System.Drawing.Size(75, 23);
            this.bt_truotx.TabIndex = 14;
            this.bt_truotx.Text = "TruotX";
            this.bt_truotx.UseVisualStyleBackColor = true;
            this.bt_truotx.Click += new System.EventHandler(this.bt_truotx_Click);
            // 
            // bt_truoty
            // 
            this.bt_truoty.Location = new System.Drawing.Point(12, 68);
            this.bt_truoty.Name = "bt_truoty";
            this.bt_truoty.Size = new System.Drawing.Size(75, 23);
            this.bt_truoty.TabIndex = 15;
            this.bt_truoty.Text = "TruotY";
            this.bt_truoty.UseVisualStyleBackColor = true;
            this.bt_truoty.Click += new System.EventHandler(this.bt_truoty_Click);
            // 
            // nud_dtx
            // 
            this.nud_dtx.Location = new System.Drawing.Point(109, 42);
            this.nud_dtx.Name = "nud_dtx";
            this.nud_dtx.Size = new System.Drawing.Size(31, 20);
            this.nud_dtx.TabIndex = 16;
            this.nud_dtx.ValueChanged += new System.EventHandler(this.nud_dtx_ValueChanged);
            // 
            // nud_dty
            // 
            this.nud_dty.Location = new System.Drawing.Point(109, 71);
            this.nud_dty.Name = "nud_dty";
            this.nud_dty.Size = new System.Drawing.Size(31, 20);
            this.nud_dty.TabIndex = 17;
            this.nud_dty.ValueChanged += new System.EventHandler(this.nud_dty_ValueChanged);
            // 
            // tinhtienx
            // 
            this.tinhtienx.Location = new System.Drawing.Point(158, 39);
            this.tinhtienx.Name = "tinhtienx";
            this.tinhtienx.Size = new System.Drawing.Size(75, 23);
            this.tinhtienx.TabIndex = 18;
            this.tinhtienx.Text = "tinhtienx";
            this.tinhtienx.UseVisualStyleBackColor = true;
            this.tinhtienx.Click += new System.EventHandler(this.tinhtienx_Click);
            // 
            // tinhtieny
            // 
            this.tinhtieny.Location = new System.Drawing.Point(158, 68);
            this.tinhtieny.Name = "tinhtieny";
            this.tinhtieny.Size = new System.Drawing.Size(75, 23);
            this.tinhtieny.TabIndex = 19;
            this.tinhtieny.Text = "tinhtieny";
            this.tinhtieny.UseVisualStyleBackColor = true;
            this.tinhtieny.Click += new System.EventHandler(this.tinhtieny_Click);
            // 
            // tb_ttx
            // 
            this.tb_ttx.Location = new System.Drawing.Point(239, 39);
            this.tb_ttx.Name = "tb_ttx";
            this.tb_ttx.Size = new System.Drawing.Size(44, 20);
            this.tb_ttx.TabIndex = 20;
            this.tb_ttx.TextChanged += new System.EventHandler(this.tb_ttx_TextChanged);
            // 
            // tb_tty
            // 
            this.tb_tty.Location = new System.Drawing.Point(239, 71);
            this.tb_tty.Name = "tb_tty";
            this.tb_tty.Size = new System.Drawing.Size(44, 20);
            this.tb_tty.TabIndex = 21;
            this.tb_tty.TextChanged += new System.EventHandler(this.tb_tty_TextChanged);
            // 
            // bt_Quay
            // 
            this.bt_Quay.Location = new System.Drawing.Point(289, 39);
            this.bt_Quay.Name = "bt_Quay";
            this.bt_Quay.Size = new System.Drawing.Size(75, 23);
            this.bt_Quay.TabIndex = 22;
            this.bt_Quay.Text = "Quay";
            this.bt_Quay.UseVisualStyleBackColor = true;
            this.bt_Quay.Click += new System.EventHandler(this.bt_Quay_Click);
            // 
            // tb_Quay
            // 
            this.tb_Quay.Location = new System.Drawing.Point(370, 39);
            this.tb_Quay.Name = "tb_Quay";
            this.tb_Quay.Size = new System.Drawing.Size(35, 20);
            this.tb_Quay.TabIndex = 23;
            this.tb_Quay.TextChanged += new System.EventHandler(this.tb_Quay_TextChanged);
            // 
            // bt_cogian
            // 
            this.bt_cogian.Location = new System.Drawing.Point(289, 71);
            this.bt_cogian.Name = "bt_cogian";
            this.bt_cogian.Size = new System.Drawing.Size(75, 23);
            this.bt_cogian.TabIndex = 24;
            this.bt_cogian.Text = "Co Gian";
            this.bt_cogian.UseVisualStyleBackColor = true;
            this.bt_cogian.Click += new System.EventHandler(this.bt_cogian_Click);
            // 
            // nud_cogian
            // 
            this.nud_cogian.Location = new System.Drawing.Point(370, 74);
            this.nud_cogian.Name = "nud_cogian";
            this.nud_cogian.Size = new System.Drawing.Size(35, 20);
            this.nud_cogian.TabIndex = 25;
            this.nud_cogian.ValueChanged += new System.EventHandler(this.nud_cogian_ValueChanged);
            // 
            // bt_dxox
            // 
            this.bt_dxox.Location = new System.Drawing.Point(417, 37);
            this.bt_dxox.Name = "bt_dxox";
            this.bt_dxox.Size = new System.Drawing.Size(87, 23);
            this.bt_dxox.TabIndex = 26;
            this.bt_dxox.Text = "Doi Xung OX";
            this.bt_dxox.UseVisualStyleBackColor = true;
            this.bt_dxox.Click += new System.EventHandler(this.bt_dxox_Click);
            // 
            // bt_dxoy
            // 
            this.bt_dxoy.Location = new System.Drawing.Point(417, 71);
            this.bt_dxoy.Name = "bt_dxoy";
            this.bt_dxoy.Size = new System.Drawing.Size(87, 23);
            this.bt_dxoy.TabIndex = 27;
            this.bt_dxoy.Text = "Doi Xung OY";
            this.bt_dxoy.UseVisualStyleBackColor = true;
            this.bt_dxoy.Click += new System.EventHandler(this.bt_dxoy_Click);
            // 
            // bt_DaGiac
            // 
            this.bt_DaGiac.Location = new System.Drawing.Point(510, 39);
            this.bt_DaGiac.Name = "bt_DaGiac";
            this.bt_DaGiac.Size = new System.Drawing.Size(75, 23);
            this.bt_DaGiac.TabIndex = 28;
            this.bt_DaGiac.Text = "Đa Giác";
            this.bt_DaGiac.UseVisualStyleBackColor = true;
            this.bt_DaGiac.Click += new System.EventHandler(this.bt_DaGiac_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(789, 450);
            this.Controls.Add(this.bt_DaGiac);
            this.Controls.Add(this.bt_dxoy);
            this.Controls.Add(this.bt_dxox);
            this.Controls.Add(this.nud_cogian);
            this.Controls.Add(this.bt_cogian);
            this.Controls.Add(this.tb_Quay);
            this.Controls.Add(this.bt_Quay);
            this.Controls.Add(this.tb_tty);
            this.Controls.Add(this.tb_ttx);
            this.Controls.Add(this.tinhtieny);
            this.Controls.Add(this.tinhtienx);
            this.Controls.Add(this.nud_dty);
            this.Controls.Add(this.nud_dtx);
            this.Controls.Add(this.bt_truoty);
            this.Controls.Add(this.bt_truotx);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txb_Time);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.bt_Hexagon);
            this.Controls.Add(this.bt_Pentagonal);
            this.Controls.Add(this.bt_Triangle);
            this.Controls.Add(this.bt_Rectangle);
            this.Controls.Add(this.bt_Ellipse);
            this.Controls.Add(this.bt_Circle);
            this.Controls.Add(this.bt_BangMau);
            this.Controls.Add(this.bt_Line);
            this.Controls.Add(this.openGLControl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dtx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_dty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_cogian)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private SharpGL.OpenGLControl openGLControl;
        private System.Windows.Forms.Button bt_Line;
        private System.Windows.Forms.Button bt_BangMau;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button bt_Circle;
        private System.Windows.Forms.Button bt_Ellipse;
        private System.Windows.Forms.Button bt_Rectangle;
        private System.Windows.Forms.Button bt_Triangle;
        private System.Windows.Forms.Button bt_Pentagonal;
        private System.Windows.Forms.Button bt_Hexagon;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.TextBox txb_Time;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bt_truotx;
        private System.Windows.Forms.Button bt_truoty;
        private System.Windows.Forms.NumericUpDown nud_dtx;
        private System.Windows.Forms.NumericUpDown nud_dty;
        private System.Windows.Forms.Button tinhtienx;
        private System.Windows.Forms.Button tinhtieny;
        private System.Windows.Forms.TextBox tb_ttx;
        private System.Windows.Forms.TextBox tb_tty;
        private System.Windows.Forms.Button bt_Quay;
        private System.Windows.Forms.TextBox tb_Quay;
        private System.Windows.Forms.Button bt_cogian;
        private System.Windows.Forms.NumericUpDown nud_cogian;
        private System.Windows.Forms.Button bt_dxox;
        private System.Windows.Forms.Button bt_dxoy;
        private System.Windows.Forms.Button bt_DaGiac;
    }
}

