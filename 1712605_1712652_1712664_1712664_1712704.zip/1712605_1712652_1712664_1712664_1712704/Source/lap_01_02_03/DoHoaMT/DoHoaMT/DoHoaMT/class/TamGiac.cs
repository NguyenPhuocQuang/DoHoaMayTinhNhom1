﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using SharpGL;
using DoHoaMT.ClassDuongThang;

namespace DoHoaMT.ClassTamGiac
{
   public class TamGiac
    {
        private Point Startpoint;
        private Point Endpoint;

        public void VeTamGiac(Point pStart, Point pEnd, OpenGL gl)//phương thức vẽ tam giác dựa trên vẽ đoạn thẳng
        {
            Point p1 = new Point(pStart.X, pStart.Y); //điểm thứ 1

            Point p2 = new Point(pEnd.X, pStart.Y);// diem thu 2

            int h = (int)Math.Sqrt(Math.Pow(pEnd.X - pStart.X, 2) + Math.Pow(pEnd.Y - pStart.Y, 2)); //tinh chieu cao tam giác đều
            h = (int)(h * 0.867);
            Point p3 = new Point((pStart.X + pEnd.X) / 2, pStart.Y - h);// diem thu 3 được tính theo điểm p1 và p2

            duongthang dt1 = new duongthang(); //lan luoc ve cac canh
            dt1.Veduongthang(p1, p2, gl);

            duongthang dt2 = new duongthang(); //lan luoc ve cac canh
            dt2.Veduongthang(p2, p3, gl);

            duongthang dt3 = new duongthang(); //lan luoc ve cac canh
            dt3.Veduongthang(p1, p3, gl);
        }
    }
}
