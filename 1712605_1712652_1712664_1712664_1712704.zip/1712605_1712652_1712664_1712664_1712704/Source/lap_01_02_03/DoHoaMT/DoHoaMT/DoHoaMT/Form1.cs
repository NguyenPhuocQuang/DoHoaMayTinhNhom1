﻿using SharpGL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DoHoaMT.ClassDuongThang;
using DoHoaMT.ClassDuongTron;
using DoHoaMT.ClassEllipse;
using DoHoaMT.ClassTamGiac;
using DoHoaMT.ClassChuNhat;
using DoHoaMT.ClassLucGiacDeu;
using DoHoaMT.ClassNguGiacDeu;
using System.Diagnostics;
using DoHoaMT.classPhepTruot;
using DoHoaMT.ClassDaGiac;


namespace DoHoaMT
{

    public partial class Form1 : Form
    {
        Color colorUserColor;
        short shShape;
        int UserLineWidth;
        int tx;
        int ty;
        int cogian;
        string ttx;
        string tty;
        string quay;
        double timeDraw;
        private Point pStart;
        private Point pEnd;
        private Point pst;//diem bat dau
        private Point pen;//dieam ke thuc
        private bool shouldDraw;
        private int shouldtruot = 0;//khi nao nen thuc hiencacs pheps bien doi affine
        private Point pDagiac;
        private List<Point> dsPoint = new List<Point>();
        bool ktdagiac;
        bool check = false;
        
        public Form1()
        {
            InitializeComponent();
            colorUserColor = Color.White; //mau ban dau
            shShape = 0; // biến lưu hình cần vẽ
            UserLineWidth = 1; //biến lưu độ dày nét vẽ cua người dùng
            shouldDraw = false; //biến kiểm tra co can ve hay không
            timeDraw = 88;
            ktdagiac = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void openGLControl_OpenGLInitialized(object sender, EventArgs e)
        {
            // Get the OpenGL object.
            OpenGL gl = openGLControl.OpenGL;
            // Set the clear color.
            gl.ClearColor(0, 0, 0, 0);
            // Set the projection matrix.
            gl.MatrixMode(OpenGL.GL_PROJECTION);
            // Load the identity.
            gl.LoadIdentity();
        }


        private void openGLControl_Load(object sender, EventArgs e)
        {

        }

        private void openGLControl_OpenGLDraw(object sender, RenderEventArgs args)
        {
            Stopwatch st = new Stopwatch(); //khai báo phương thức tính thời gian

            if (shouldDraw == true && shShape == 0)//ve doan thang
            {

                st.Reset(); // reset thời gian
                st.Start(); //bat đầu tính thời gian

                OpenGL gl = openGLControl.OpenGL;
                gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
                gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
                // do day net ve
                gl.PointSize(UserLineWidth);                            
                duongthang dt = new duongthang(); //khai bao đối tượng đường thẳng 
                dt.Veduongthang(pStart, pEnd, gl); // phương thức vẽ đường thẳng từ 2 điểm
                
                if (shouldtruot == 0)
                {
                    pst = pStart;
                    pen = pEnd;
                }

                st.Stop(); // kết thúc đo thời gian
                timeDraw = st.ElapsedMilliseconds; // thời gian thực hiện
                
                txb_Time.Text = timeDraw.ToString();
            }
            else if (shouldDraw == true && shShape == 1)//ve duong tron
            {
                // Get the OpenGL object.
                OpenGL gl = openGLControl.OpenGL;
                // Clear the color and depth buffer.
                gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
                //chon mau
                gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
                gl.PointSize(UserLineWidth); // do day net ve

                gl.Begin(OpenGL.GL_POINTS); // Chọn chế độ ve

                st.Reset(); // reset thời gian
                st.Start(); //bat đầu tính thời gian

                duongtron dtron = new duongtron(); //class duong tron
                dtron.Veduongtron(pStart, pEnd, gl);
                if (shouldtruot == 0)
                {
                    pst = pStart;
                    pen = pEnd;
                }

                st.Stop(); // kết thúc đo thời gian
                timeDraw = st.ElapsedMilliseconds; // thời gian thực hiện
                txb_Time.Text = timeDraw.ToString();
            }
            else if (shouldDraw == true && shShape == 2)//hinh eclipes
            {
                // Get the OpenGL object.
                OpenGL gl = openGLControl.OpenGL;
                // Clear the color and depth buffer.
                gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

                // Vẽ vời chỗ này. Ví dụ:
                gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
                gl.PointSize(UserLineWidth); // do day net ve
                gl.Begin(OpenGL.GL_POINTS);

                st.Reset(); // reset thời gian
                st.Start(); //bat đầu tính thời gian

                eclipse ecli = new eclipse(); // class eclipse
                ecli.Veeclipse(pStart, pEnd, gl);
                if (shouldtruot == 0)
                {
                    pst = pStart;
                    pen = pEnd;
                }

                st.Stop(); // kết thúc đo thời gian
                timeDraw = st.ElapsedMilliseconds; // thời gian thực hiện
                txb_Time.Text = timeDraw.ToString();

            }
            else if (shouldDraw == true && shShape == 6) //ve hinh chu nhat
            {
                // Get the OpenGL object.
                OpenGL gl = openGLControl.OpenGL;
                // Clear the color and depth buffer.
                gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

                // Vẽ vời chỗ này. Ví dụ:
                gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
                gl.PointSize(UserLineWidth); // do day net ve
                gl.Begin(OpenGL.GL_POINTS);

                st.Reset(); // reset thời gian
                st.Start(); //bat đầu tính thời gian

                ChuNhat chunhat = new ChuNhat();
                chunhat.VeHinhChuNHat(pStart, pEnd, gl);
                if (shouldtruot == 0)
                {
                    pst = pStart;
                    pen = pEnd;
                }

                st.Stop(); // kết thúc đo thời gian
                timeDraw = st.ElapsedMilliseconds; // thời gian thực hiện
                txb_Time.Text = timeDraw.ToString();

            }
            else if (shouldDraw == true && shShape == 3)//ve tam giác
            {
                // Get the OpenGL object.
                OpenGL gl = openGLControl.OpenGL;
                // Clear the color and depth buffer.
                gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

                // Vẽ vời chỗ này. Ví dụ:
                gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
                gl.PointSize(UserLineWidth); // do day net ve
                gl.Begin(OpenGL.GL_POINTS);

                st.Reset(); // reset thời gian
                st.Start(); //bat đầu tính thời gian

                TamGiac tamgiac = new TamGiac();
                tamgiac.VeTamGiac(pStart, pEnd, gl);
                if (shouldtruot == 0)
                {
                    pst = pStart;
                    pen = pEnd;
                }

                st.Stop(); // kết thúc đo thời gian
                timeDraw = st.ElapsedMilliseconds; // thời gian thực hiện
                txb_Time.Text = timeDraw.ToString();
            }
            else if (shouldDraw == true && shShape == 5)// ngũ giác đều
            {
                // Get the OpenGL object.
                OpenGL gl = openGLControl.OpenGL;
                // Clear the color and depth buffer.
                gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

                // Vẽ vời chỗ này. Ví dụ:
              
                gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
                gl.PointSize(UserLineWidth); // do day net ve
                gl.Begin(OpenGL.GL_POINTS);

                st.Reset(); // reset thời gian
                st.Start(); //bat đầu tính thời gian

                NguGiacDeu ngugiac = new NguGiacDeu();
                ngugiac.VeNguGiacDeu(pStart, pEnd, gl);
                if (shouldtruot == 0)
                {
                    pst = pStart;
                    pen = pEnd;
                }

                st.Stop(); // kết thúc đo thời gian
                timeDraw = st.ElapsedMilliseconds; // thời gian thực hiện
                txb_Time.Text = timeDraw.ToString();

            }
            else if (shouldDraw == true && shShape == 4)// vẽ lục giác đều
            {
                // Get the OpenGL object.
                OpenGL gl = openGLControl.OpenGL;
                // Clear the color and depth buffer.
                gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

                gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);//thay doi mau net ve
                gl.PointSize(UserLineWidth); // do day net ve
                gl.Begin(OpenGL.GL_POINTS);

                st.Reset(); // reset thời gian
                st.Start(); //bat đầu tính thời gian

                LucGiacDeu lucgiacdeu = new LucGiacDeu(); //gọi class de ve hinh
                lucgiacdeu.VeLucGiacDeu(pStart, pEnd, gl);
                if (shouldtruot == 0)
                {
                    pst = pStart;
                    pen = pEnd;
                }

                st.Stop(); // kết thúc đo thời gian
                timeDraw = st.ElapsedMilliseconds; // thời gian thực hiện
                txb_Time.Text = timeDraw.ToString();

            }
            else if (ktdagiac == true)
            {
                // Get the OpenGL object.
                OpenGL gl = openGLControl.OpenGL;
                // Clear the color and depth buffer.
                gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);

                gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);//thay doi mau net ve
                gl.PointSize(UserLineWidth); // do day net ve
                gl.Begin(OpenGL.GL_POINTS);

                st.Reset(); // reset thời gian
                st.Start(); //bat đầu tính thời gian


                DaGiac dagiac = new DaGiac();
                dagiac.VeDaGiac(gl, dsPoint);

                st.Stop(); // kết thúc đo thời gian
                timeDraw = st.ElapsedMilliseconds; // thời gian thực hiện
                txb_Time.Text = timeDraw.ToString();
                if (check == true)
                {
                    ktdagiac = false;
                    dsPoint.Clear();
                    check = false;
                }
            }
        }

        private void openGLControl_Resized(object sender, EventArgs e)
        {
            // Get the OpenGL object.
            OpenGL gl = openGLControl.OpenGL;
            // Set the projection matrix.
            gl.MatrixMode(OpenGL.GL_PROJECTION);
            // Load the identity.
            gl.LoadIdentity();
            // Create a perspective transformation.
            gl.Viewport(0, 0, openGLControl.Width, openGLControl.Height);
            gl.Ortho2D(0, openGLControl.Width, 0, openGLControl.Height);
        }

        private void openGLControl_MouseDown(object sender, MouseEventArgs e)//hàm bắt sự kiện nhấp chuột
        {
            shouldDraw = true;//nếu người dùng nhấp chuột thì bắt đầu vẽ
            pStart = e.Location; //tọa độ điểm đầu là tọa độ người dùng nhấp chuột
            pEnd = pStart; //gán giá trị cho điểm cuối
            if ((ktdagiac == true) && (e.Button == MouseButtons.Left))
            {
                dsPoint.Add(e.Location);
            }
        }

        private void openGLControl_MouseMove(object sender, MouseEventArgs e)//hàm bắc sự kiện duy chuyễn chuột
        {
            pEnd = e.Location; //lấy tọa độ chuột khi người dùng duy chuyễn trên màng hình
        }

        private void openGLControl_MouseUp(object sender, MouseEventArgs e)//hàm bắt sự kiện buông chuột
        {

            pEnd = e.Location; //lấy tọa độ chuột lúc người dùng buôn chuột làm tọa độ cuối
            shouldDraw = false; //nếu người dùng buôn chuột thì không cần vẽ tiếp

        }

        private void bt_BangMau_Click(object sender, EventArgs e)//láy giá trị màu người dùng chọn để thay đổi màu vẽ
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                colorUserColor = colorDialog1.Color;// nếu người dùng nhấn ok thì trả về giá trị màu
            }
        }

        private void bt_Line_Click(object sender, EventArgs e)//lấy sự kiện click chuột của người dùng
        {
            shShape = 0; //biến lưu giá trị đại điện cho hình cần vẽ
        }

        private void bt_Circle_Click(object sender, EventArgs e)
        {
            shShape = 1;//biến lưu giá trị đại điện cho hình cần vẽ
        }

        private void bt_Rectangle_Click(object sender, EventArgs e)
        {
            shShape = 6;//biến lưu giá trị đại điện cho hình cần vẽ
        }

        private void bt_Triangle_Click(object sender, EventArgs e)
        {
            shShape = 3;//biến lưu giá trị đại điện cho hình cần vẽ
        }

        private void bt_Pentagonal_Click(object sender, EventArgs e)
        {
            shShape = 5;//biến lưu giá trị đại điện cho hình cần vẽ
        }

        private void bt_Hexagon_Click(object sender, EventArgs e)
        {
            shShape = 4;//biến lưu giá trị đại điện cho hình cần vẽ
        }

        private void bt_Ellipse_Click(object sender, EventArgs e)
        {
            shShape = 2;//biến lưu giá trị đại điện cho hình cần vẽ
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)//lấy giá trị người dùng chọn để thay đổi độ dày nét vẽ
        {
            UserLineWidth = (int)numericUpDown1.Value;// hàm lấy giá trị người dùng nhập
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txb_Time_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void bt_truotx_Click(object sender, EventArgs e)
        {
            shouldtruot = 1;
            OpenGL gl = openGLControl.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
            // do day net ve
            gl.PointSize(UserLineWidth);
            PhepTruot t = new PhepTruot();
            int x1 = pst.X;
            int x2 = pen.X;
            int y1 = pst.Y;
            int y2 = pen.Y;
            t.TruotX(ref x1, ref x2, ref y1, ref y2, gl, tx);//truot theo ox
            pst.X = x1;
            pst.Y = y1;
            pen.X = x2;
            pen.Y = y2;
            if (shShape == 0)
            {
                duongthang dt = new duongthang(); //khai bao đối tượng đường thẳng 
                dt.Veduongthang(pst, pen, gl); // phương thức vẽ đường thẳng từ 2 điểm
            }
            else if (shShape == 1)
            {
                duongtron dtron = new duongtron(); //class duong tron
                dtron.Veduongtron(pst, pen, gl);
            }
            else if (shShape == 2)
            {
                eclipse ecli = new eclipse(); // class eclipse
                ecli.Veeclipse(pst, pen, gl);
            }
            else if (shShape == 3)
            {
                TamGiac tamgiac = new TamGiac();//ve tam giac
                tamgiac.VeTamGiac(pst, pen, gl);
            }
            else if (shShape == 4)
            {
                LucGiacDeu lucgiacdeu = new LucGiacDeu(); //gọi class de ve hinh
                lucgiacdeu.VeLucGiacDeu(pst, pen, gl);
            }
            else if (shShape == 5)
            {
                NguGiacDeu ngugiac = new NguGiacDeu();//ve ngu giac
                ngugiac.VeNguGiacDeu(pst, pen, gl);
            }
            else if (shShape == 6)
            {
                ChuNhat chunhat = new ChuNhat();
                chunhat.VeHinhChuNHat(pst, pen, gl);//ve hcn
            }
            shouldtruot = 0;
        }

        private void nud_dtx_ValueChanged(object sender, EventArgs e)//lấy độ trượt theo trục ox
        {
            tx = (int)numericUpDown1.Value;// hàm lấy giá trị người dùng nhập
        }

        private void bt_truoty_Click(object sender, EventArgs e)
        {
            shouldtruot = 1;
            OpenGL gl = openGLControl.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
            // do day net ve
            gl.PointSize(UserLineWidth);
            PhepTruot t = new PhepTruot();
            int x1 = pst.X;
            int x2 = pen.X;
            int y1 = pst.Y;
            int y2 = pen.Y;
            t.TruotY(ref x1, ref x2, ref y1, ref y2, gl, ty);//truotwj theo oy
            pst.X = x1;
            pst.Y = y1;
            pen.X = x2;
            pen.Y = y2;
            if (shShape == 0)
            {
                duongthang dt = new duongthang(); //khai bao đối tượng đường thẳng 
                dt.Veduongthang(pst, pen, gl); // phương thức vẽ đường thẳng từ 2 điểm
            }
            else if(shShape==1)
            {
                duongtron dtron = new duongtron(); //class duong tron
                dtron.Veduongtron(pst, pen, gl);
            }
            else if(shShape==2)
            {
                eclipse ecli = new eclipse(); // class eclipse
                ecli.Veeclipse(pst, pen, gl);
            }
            else if(shShape==3)
            {
                TamGiac tamgiac = new TamGiac();//ve tam giac
                tamgiac.VeTamGiac(pst, pen, gl);
            }
            else if(shShape==4)
            {
                LucGiacDeu lucgiacdeu = new LucGiacDeu(); //gọi class de ve hinh
                lucgiacdeu.VeLucGiacDeu(pst, pen, gl);
            }
            else if(shShape==5)
            {
                NguGiacDeu ngugiac = new NguGiacDeu();
                ngugiac.VeNguGiacDeu(pst, pen, gl);//ve ngu giac
            }
            else if(shShape==6)
            {
                ChuNhat chunhat = new ChuNhat();//ve hcn
                chunhat.VeHinhChuNHat(pst, pen, gl);
            }
            
            shouldtruot = 0;
        }

        private void nud_dty_ValueChanged(object sender, EventArgs e)//lấy độ trượt theo trục oy
        {
            ty = (int)numericUpDown1.Value;// hàm lấy giá trị người dùng nhập
        }

        

        private void tinhtieny_Click(object sender, EventArgs e)
        {
            shouldtruot = 1;
            OpenGL gl = openGLControl.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
            // do day net ve
            gl.PointSize(UserLineWidth);
            PhepTruot t = new PhepTruot();
            int x1 = pst.X;
            int x2 = pen.X;
            int y1 = pst.Y;
            int y2 = pen.Y;
            t.TinhTienY(ref x1, ref x2, ref y1, ref y2, gl, tty);//tinh tien theo oy
            pst.X = x1;
            pst.Y = y1;
            pen.X = x2;
            pen.Y = y2;
            if (shShape == 0)
            {
                duongthang dt = new duongthang(); //khai bao đối tượng đường thẳng 
                dt.Veduongthang(pst, pen, gl); // phương thức vẽ đường thẳng từ 2 điểm
            }
            else if (shShape == 1)
            {
                duongtron dtron = new duongtron(); //class duong tron
                dtron.Veduongtron(pst, pen, gl);
            }
            else if (shShape == 2)
            {
                eclipse ecli = new eclipse(); // class eclipse
                ecli.Veeclipse(pst, pen, gl);
            }
            else if (shShape == 3)
            {
                TamGiac tamgiac = new TamGiac();
                tamgiac.VeTamGiac(pst, pen, gl);//ve tam giac
            }
            else if (shShape == 4)
            {
                LucGiacDeu lucgiacdeu = new LucGiacDeu(); //gọi class de ve hinh
                lucgiacdeu.VeLucGiacDeu(pst, pen, gl);
            }
            else if (shShape == 5)
            {
                NguGiacDeu ngugiac = new NguGiacDeu();
                ngugiac.VeNguGiacDeu(pst, pen, gl);//ve ngu giac
            }
            else if (shShape == 6)
            {
                ChuNhat chunhat = new ChuNhat();
                chunhat.VeHinhChuNHat(pst, pen, gl);//ve hcn
            }
            shouldtruot = 0;
        }

        private void tinhtienx_Click(object sender, EventArgs e)
        {
            shouldtruot = 1;
            OpenGL gl = openGLControl.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
            // do day net ve
            gl.PointSize(UserLineWidth);
            PhepTruot t = new PhepTruot();
            int x1 = pst.X;
            int x2 = pen.X;
            int y1 = pst.Y;
            int y2 = pen.Y;
            t.TinhTienX(ref x1, ref x2, ref y1, ref y2, gl, ttx);//phep tinh tien theo ox
            pst.X = x1;
            pst.Y = y1;
            pen.X = x2;
            pen.Y = y2;
            if (shShape == 0)
            {
                duongthang dt = new duongthang(); //khai bao đối tượng đường thẳng 
                dt.Veduongthang(pst, pen, gl); // phương thức vẽ đường thẳng từ 2 điểm
            }
            else if (shShape == 1)
            {
                duongtron dtron = new duongtron(); //class duong tron
                dtron.Veduongtron(pst, pen, gl);
            }
            else if (shShape == 2)
            {
                eclipse ecli = new eclipse(); // class eclipse
                ecli.Veeclipse(pst, pen, gl);
            }
            else if (shShape == 3)
            {
                TamGiac tamgiac = new TamGiac();
                tamgiac.VeTamGiac(pst, pen, gl);//ve tam giac
            }
            else if (shShape == 4)
            {
                LucGiacDeu lucgiacdeu = new LucGiacDeu(); //gọi class de ve hinh
                lucgiacdeu.VeLucGiacDeu(pst, pen, gl);
            }
            else if (shShape == 5)
            {
                NguGiacDeu ngugiac = new NguGiacDeu();//ve ngu giac
                ngugiac.VeNguGiacDeu(pst, pen, gl);
            }
            else if (shShape == 6)
            {
                ChuNhat chunhat = new ChuNhat();//ve hcn
                chunhat.VeHinhChuNHat(pst, pen, gl);
            }
            shouldtruot = 0;
        }

        private void tb_ttx_TextChanged(object sender, EventArgs e)
        {

            ttx = tb_ttx.Text;
            //ttx = int.Parse(s);
        }

        private void tb_tty_TextChanged(object sender, EventArgs e)
        {
            tty = tb_tty.Text;
            //tty = int.Parse(s);
        }

        private void bt_Quay_Click(object sender, EventArgs e)
        {
            shouldtruot = 1;
            OpenGL gl = openGLControl.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
            // do day net ve
            gl.PointSize(UserLineWidth);
            PhepTruot t = new PhepTruot();
            int x1 = pst.X;
            int x2 = pen.X;
            int y1 = pst.Y;
            int y2 = pen.Y;
            t.PhepQuay(ref x1, ref x2, ref y1, ref y2, gl, quay);//phep quay
            pst.X = x1;
            pst.Y = y1;
            pen.X = x2;
            pen.Y = y2;
            if(shShape==0)
            {
                duongthang dt = new duongthang(); //khai bao đối tượng đường thẳng 
                dt.Veduongthang(pst, pen, gl); // phương thức vẽ đường thẳng từ 2 điểm
            }
            else if (shShape == 1)
            {
                duongtron dtron = new duongtron(); //class duong tron
                dtron.Veduongtron(pst, pen, gl);
            }
            else if (shShape == 2)
            {
                eclipse ecli = new eclipse(); // class eclipse
                ecli.Veeclipse(pst, pen, gl);
            }
            else if (shShape == 3)
            {
                TamGiac tamgiac = new TamGiac();
                tamgiac.VeTamGiac(pst, pen, gl);//ve tam giac
            }
            else if (shShape == 4)
            {
                LucGiacDeu lucgiacdeu = new LucGiacDeu(); //gọi class de ve hinh
                lucgiacdeu.VeLucGiacDeu(pst, pen, gl);
            }
            else if (shShape == 5)
            {
                NguGiacDeu ngugiac = new NguGiacDeu();
                ngugiac.VeNguGiacDeu(pst, pen, gl);//ve ngu giac
            }
            else if (shShape == 6)
            {
                ChuNhat chunhat = new ChuNhat();//ve hcn
                chunhat.VeHinhChuNHat(pst, pen, gl);
            }
            shouldtruot = 0;
        }

        private void tb_Quay_TextChanged(object sender, EventArgs e)
        {
            quay = tb_Quay.Text;//lấy giá trị người dùng nhập
        }

        private void bt_cogian_Click(object sender, EventArgs e)
        {
            shouldtruot = 1;
            OpenGL gl = openGLControl.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
            // do day net ve
            gl.PointSize(UserLineWidth);
            PhepTruot t = new PhepTruot();
            int x1 = pst.X;
            int x2 = pen.X;
            int y1 = pst.Y;
            int y2 = pen.Y;
            t.PhepCoGian(ref x1, ref x2, ref y1, ref y2, gl, cogian);//phep co gian
            pst.X = x1;
            pst.Y = y1;
            pen.X = x2;
            pen.Y = y2;
            if (shShape == 0)
            {
                duongthang dt = new duongthang(); //khai bao đối tượng đường thẳng 
                dt.Veduongthang(pst, pen, gl); // phương thức vẽ đường thẳng từ 2 điểm
            }
            else if (shShape == 1)
            {
                duongtron dtron = new duongtron(); //class duong tron
                dtron.Veduongtron(pst, pen, gl);
            }
            else if (shShape == 2)
            {
                eclipse ecli = new eclipse(); // class eclipse
                ecli.Veeclipse(pst, pen, gl);
            }
            else if (shShape == 3)
            {
                TamGiac tamgiac = new TamGiac();
                tamgiac.VeTamGiac(pst, pen, gl);///ve  tam giac
            }
            else if (shShape == 4)
            {
                LucGiacDeu lucgiacdeu = new LucGiacDeu(); //gọi class de ve hinh
                lucgiacdeu.VeLucGiacDeu(pst, pen, gl);
            }
            else if (shShape == 5)
            {
                NguGiacDeu ngugiac = new NguGiacDeu();//ve ngu giac
                ngugiac.VeNguGiacDeu(pst, pen, gl);
            }
            else if (shShape == 6)
            {
                ChuNhat chunhat = new ChuNhat();
                chunhat.VeHinhChuNHat(pst, pen, gl);//ve hcn
            }
            shouldtruot = 0;
        }

        private void nud_cogian_ValueChanged(object sender, EventArgs e)
        {
            cogian = (int)nud_cogian.Value;
        }

        private void bt_dxox_Click(object sender, EventArgs e)
        {
            shouldtruot = 1;
            OpenGL gl = openGLControl.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
            // do day net ve
            gl.PointSize(UserLineWidth);
            PhepTruot t = new PhepTruot();
            int x1 = pst.X;
            int x2 = pen.X;
            int y1 = pst.Y;
            int y2 = pen.Y;
            t.PhepDXOX(ref x1, ref x2, ref y1, ref y2, gl);//phep doi xung ox
            pst.X = x1;
            pst.Y = y1;
            pen.X = x2;
            pen.Y = y2;
            if (shShape == 0)
            {
                duongthang dt = new duongthang(); //khai bao đối tượng đường thẳng 
                dt.Veduongthang(pst, pen, gl); // phương thức vẽ đường thẳng từ 2 điểm
            }
            else if (shShape == 1)
            {
                duongtron dtron = new duongtron(); //class duong tron
                dtron.Veduongtron(pst, pen, gl);
            }
            else if (shShape == 2)
            {
                eclipse ecli = new eclipse(); // class eclipse
                ecli.Veeclipse(pst, pen, gl);
            }
            else if (shShape == 3)
            {
                TamGiac tamgiac = new TamGiac();
                tamgiac.VeTamGiac(pst, pen, gl);//ve tam giac
            }
            else if (shShape == 4)
            {
                LucGiacDeu lucgiacdeu = new LucGiacDeu(); //gọi class de ve hinh
                lucgiacdeu.VeLucGiacDeu(pst, pen, gl);
            }
            else if (shShape == 5)
            {
                NguGiacDeu ngugiac = new NguGiacDeu();//ve ngu giac
                ngugiac.VeNguGiacDeu(pst, pen, gl);
            }
            else if (shShape == 6)
            {
                ChuNhat chunhat = new ChuNhat();
                chunhat.VeHinhChuNHat(pst, pen, gl);//ve hcn
            }
            shouldtruot = 0;
        }

        private void bt_dxoy_Click(object sender, EventArgs e)
        {
            shouldtruot = 1;
            OpenGL gl = openGLControl.OpenGL;
            gl.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            gl.Color(colorUserColor.R / 255.0, colorUserColor.G / 255.0, colorUserColor.B / 255.0);
            // do day net ve
            gl.PointSize(UserLineWidth);
            PhepTruot t = new PhepTruot();
            int x1 = pst.X;
            int x2 = pen.X;
            int y1 = pst.Y;
            int y2 = pen.Y;
            t.PhepDXOY(ref x1, ref x2, ref y1, ref y2, gl);
            pst.X = x1;
            pst.Y = y1;
            pen.X = x2;
            pen.Y = y2;
            if (shShape == 0)
            {
                duongthang dt = new duongthang(); //khai bao đối tượng đường thẳng 
                dt.Veduongthang(pst, pen, gl); // phương thức vẽ đường thẳng từ 2 điểm
            }
            else if (shShape == 1)
            {
                duongtron dtron = new duongtron(); //class duong tron
                dtron.Veduongtron(pst, pen, gl);
            }
            else if (shShape == 2)
            {
                eclipse ecli = new eclipse(); // class eclipse
                ecli.Veeclipse(pst, pen, gl);
            }
            else if (shShape == 3)
            {
                TamGiac tamgiac = new TamGiac();
                tamgiac.VeTamGiac(pst, pen, gl);//ve tam giac
            }
            else if (shShape == 4)
            {
                LucGiacDeu lucgiacdeu = new LucGiacDeu(); //gọi class de ve hinh
                lucgiacdeu.VeLucGiacDeu(pst, pen, gl);
            }
            else if (shShape == 5)
            {
                NguGiacDeu ngugiac = new NguGiacDeu();
                ngugiac.VeNguGiacDeu(pst, pen, gl);//ve ngu giac
            }
            else if (shShape == 6)
            {
                ChuNhat chunhat = new ChuNhat();
                chunhat.VeHinhChuNHat(pst, pen, gl);//ve hcn
            }
            shouldtruot = 0;
        }

        private void bt_DaGiac_Click(object sender, EventArgs e)
        {
            ktdagiac = true;
        }

        private void openGLControl_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                check = true;
            }
        }
    }
}
