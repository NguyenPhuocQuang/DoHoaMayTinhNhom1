﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using SharpGL;
using DoHoaMT.ClassDuongThang;

namespace DoHoaMT.ClassNguGiacDeu
{
   public class NguGiacDeu
    {
        private Point Startpoint;
        private Point Endpoint;

        public void VeNguGiacDeu(Point pStart, Point pEnd, OpenGL gl)
        {
            const double pi = 3.1412;

            Point p1 = new Point(pEnd.X, pEnd.Y);// diem thu 1

            double alpha = (72 * pi) / 180;//góc xoay của ngũ giác là 72 độ ta đổi sang radian
            double x2, y2;
            x2 = (pEnd.X - pStart.X) * Math.Cos(alpha) - (pEnd.Y - pStart.Y) * Math.Sin(alpha) + pStart.X;// dùng phép xoay để tìm tọa độ đỉnh kế tiếp
            y2 = (pEnd.X - pStart.X) * Math.Sin(alpha) + (pEnd.Y - pStart.Y) * Math.Cos(alpha) + pStart.Y;
            Point p2 = new Point((int)x2, (int)y2);// diem thu 2

            double x3, y3;
            x3 = (x2 - pStart.X) * Math.Cos(alpha) - (y2 - pStart.Y) * Math.Sin(alpha) + pStart.X;
            y3 = (x2 - pStart.X) * Math.Sin(alpha) + (y2 - pStart.Y) * Math.Cos(alpha) + pStart.Y;

            Point p3 = new Point((int)x3, (int)y3);// diem thu 3

            double x4, y4;
            x4 = (x3 - pStart.X) * Math.Cos(alpha) - (y3 - pStart.Y) * Math.Sin(alpha) + pStart.X;
            y4 = (x3 - pStart.X) * Math.Sin(alpha) + (y3 - pStart.Y) * Math.Cos(alpha) + pStart.Y;

            Point p4 = new Point((int)x4, (int)y4);// diem thu 4

            double x5, y5;
            x5 = (x4 - pStart.X) * Math.Cos(alpha) - (y4 - pStart.Y) * Math.Sin(alpha) + pStart.X;
            y5 = (x4 - pStart.X) * Math.Sin(alpha) + (y4 - pStart.Y) * Math.Cos(alpha) + pStart.Y;

            Point p5 = new Point((int)x5, (int)y5);// diem thu 5

            duongthang dt1 = new duongthang(); //lan luoc ve cac canh
            dt1.Veduongthang(p1, p2, gl);

            duongthang dt2 = new duongthang(); //lan luoc ve cac canh
            dt2.Veduongthang(p2, p3, gl);

            duongthang dt3 = new duongthang(); //lan luoc ve cac canh
            dt3.Veduongthang(p3, p4, gl);

            duongthang dt4 = new duongthang(); //lan luoc ve cac canh
            dt4.Veduongthang(p4, p5, gl);

            duongthang dt5 = new duongthang(); //lan luoc ve cac canh
            dt5.Veduongthang(p5, p1, gl);
        }
    }
}
