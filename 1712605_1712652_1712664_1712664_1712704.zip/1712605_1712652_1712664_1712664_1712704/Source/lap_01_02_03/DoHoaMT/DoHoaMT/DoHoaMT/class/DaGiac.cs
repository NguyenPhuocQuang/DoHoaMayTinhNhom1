﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DoHoaMT.ClassDuongThang;
using System.Drawing;
using SharpGL;

namespace DoHoaMT.ClassDaGiac
{
    class DaGiac
    {
        public void VeDaGiac(OpenGL gl, List<Point> ds)
        {
            if (ds.Count <= 0)
            {
                return;
            }
            if (ds.Count == 1)
            {
                duongthang c = new duongthang();
                c.Veduongthang(ds[0], ds[0], gl);//nếu chỉ có 1 điểm thì ta vẽ 1 điểm

            }
            else  //nếu có nhiều điểm ta vẽ các điểm nối vs nhau
            {
                for (int i = 0; i < ds.Count - 1; i++)
                {

                    duongthang a = new duongthang();
                    a.Veduongthang(ds[i], ds[i + 1], gl);
                }

                duongthang b = new duongthang();
                b.Veduongthang(ds[0], ds[ds.Count - 1], gl);    //vẽ điểm đầu nối với điểm cuối
            }

        }
    }
}
