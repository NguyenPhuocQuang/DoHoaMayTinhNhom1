﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using SharpGL;

namespace DoHoaMT.ClassDuongTron
{
    public class duongtron
    {
        private Point Startpoint;
        private Point Endpoint;

        public void Veduongtron(Point pStart, Point pEnd, OpenGL gl)
        {

            int R, p0;
            int x2, y2;
            int x0, y0;

            R = (int)Math.Sqrt(Math.Pow(pEnd.X - pStart.X, 2) + Math.Pow(-pEnd.Y + pStart.Y, 2));//tinh ban kinh
            x0 = 0; ///diem dau
            y0 = R; //diem dau              

            x2 = 2 * x0;
            y2 = 2 * y0;
            int xc, yc;
            xc = (pStart.X + pEnd.X) / 2;//tinh toa do tam
            yc = (gl.RenderContextProvider.Height - pStart.Y + gl.RenderContextProvider.Height - pEnd.Y) / 2;


            p0 = 5 / 4 - R;////////////

            gl.Vertex(xc + x0, yc + y0);//ve va tinh tien cac diem theo tam
            gl.Vertex(xc - x0, yc + y0);
            gl.Vertex(xc + x0, yc - y0);
            gl.Vertex(xc - x0, yc - y0);
            gl.Vertex(xc + y0, yc + x0);
            gl.Vertex(xc - y0, yc + x0);
            gl.Vertex(xc + y0, yc - x0);
            gl.Vertex(xc - y0, yc - x0);

            for (int k = 0; x0 < y0; k++)
            {
                if (p0 < 0)
                {

                    x0++;
                    x2 += 2;
                    p0 += x2 + 1;

                }
                else if (p0 >= 0)
                {

                    x0++;
                    y0--;
                    x2 += 2;
                    y2 -= 2;
                    p0 += x2 - y2 + 1;

                }
                gl.Vertex(xc + x0, yc + y0);//ve va tinh tien cac diem theo tam
                gl.Vertex(xc - x0, yc + y0);
                gl.Vertex(xc + x0, yc - y0);
                gl.Vertex(xc - x0, yc - y0);
                gl.Vertex(xc + y0, yc + x0);
                gl.Vertex(xc - y0, yc + x0);
                gl.Vertex(xc + y0, yc - x0);
                gl.Vertex(xc - y0, yc - x0);

            }

            gl.End();
            gl.Flush();// Thực hiện lệnh vẽ ngay lập tức thay vì đợi sau 1 khoảng thời gian
        }
    }
}
