﻿namespace demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openGLControl = new SharpGL.OpenGLControl();
            this.bt_cube = new System.Windows.Forms.Button();
            this.bt_Pyramid = new System.Windows.Forms.Button();
            this.BT_langtru = new System.Windows.Forms.Button();
            this.bt_color = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.bt_pyramidTexture = new System.Windows.Forms.Button();
            this.bt_dich = new System.Windows.Forms.Button();
            this.lb_x = new System.Windows.Forms.Label();
            this.tb_dichX = new System.Windows.Forms.TextBox();
            this.lb_y = new System.Windows.Forms.Label();
            this.tb_dichY = new System.Windows.Forms.TextBox();
            this.lb_z = new System.Windows.Forms.Label();
            this.tb_dichZ = new System.Windows.Forms.TextBox();
            this.bt_scale = new System.Windows.Forms.Button();
            this.lb_scaleX = new System.Windows.Forms.Label();
            this.tb_scaleX = new System.Windows.Forms.TextBox();
            this.lb_scaley = new System.Windows.Forms.Label();
            this.tb_scaley = new System.Windows.Forms.TextBox();
            this.lb_scalez = new System.Windows.Forms.Label();
            this.tb_scalez = new System.Windows.Forms.TextBox();
            this.bt_xoay = new System.Windows.Forms.Button();
            this.lb_xoayx = new System.Windows.Forms.Label();
            this.tb_xoayx = new System.Windows.Forms.TextBox();
            this.lb_xoayy = new System.Windows.Forms.Label();
            this.tb_xoayy = new System.Windows.Forms.TextBox();
            this.lb_xoayz = new System.Windows.Forms.Label();
            this.tb_xoayz = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.tb_bankinh = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl)).BeginInit();
            this.SuspendLayout();
            // 
            // openGLControl
            // 
            this.openGLControl.DrawFPS = false;
            this.openGLControl.Location = new System.Drawing.Point(77, 87);
            this.openGLControl.Name = "openGLControl";
            this.openGLControl.OpenGLVersion = SharpGL.Version.OpenGLVersion.OpenGL2_1;
            this.openGLControl.RenderContextType = SharpGL.RenderContextType.DIBSection;
            this.openGLControl.RenderTrigger = SharpGL.RenderTrigger.TimerBased;
            this.openGLControl.Size = new System.Drawing.Size(1031, 376);
            this.openGLControl.TabIndex = 1;
            this.openGLControl.OpenGLInitialized += new System.EventHandler(this.openGLControl_OpenGLInitialized);
            this.openGLControl.OpenGLDraw += new SharpGL.RenderEventHandler(this.openGLControl_OpenGLDraw);
            this.openGLControl.Load += new System.EventHandler(this.openGLControl_Load);
            this.openGLControl.Click += new System.EventHandler(this.openGLControl_Click);
            this.openGLControl.Resize += new System.EventHandler(this.openGLControl_Resize);
            // 
            // bt_cube
            // 
            this.bt_cube.Location = new System.Drawing.Point(96, 33);
            this.bt_cube.Name = "bt_cube";
            this.bt_cube.Size = new System.Drawing.Size(75, 23);
            this.bt_cube.TabIndex = 2;
            this.bt_cube.Text = "cube";
            this.bt_cube.UseVisualStyleBackColor = true;
            this.bt_cube.Click += new System.EventHandler(this.bt_cube_Click);
            // 
            // bt_Pyramid
            // 
            this.bt_Pyramid.Location = new System.Drawing.Point(12, 33);
            this.bt_Pyramid.Name = "bt_Pyramid";
            this.bt_Pyramid.Size = new System.Drawing.Size(75, 23);
            this.bt_Pyramid.TabIndex = 3;
            this.bt_Pyramid.Text = "Pyramid";
            this.bt_Pyramid.UseVisualStyleBackColor = true;
            this.bt_Pyramid.Click += new System.EventHandler(this.bt_Pyramid_Click);
            // 
            // BT_langtru
            // 
            this.BT_langtru.Location = new System.Drawing.Point(177, 33);
            this.BT_langtru.Name = "BT_langtru";
            this.BT_langtru.Size = new System.Drawing.Size(75, 23);
            this.BT_langtru.TabIndex = 4;
            this.BT_langtru.Text = " prism";
            this.BT_langtru.UseVisualStyleBackColor = true;
            this.BT_langtru.Click += new System.EventHandler(this.BT_langtru_Click);
            // 
            // bt_color
            // 
            this.bt_color.Location = new System.Drawing.Point(339, 33);
            this.bt_color.Name = "bt_color";
            this.bt_color.Size = new System.Drawing.Size(75, 23);
            this.bt_color.TabIndex = 5;
            this.bt_color.Text = "color";
            this.bt_color.UseVisualStyleBackColor = true;
            this.bt_color.Click += new System.EventHandler(this.bt_color_Click);
            // 
            // bt_pyramidTexture
            // 
            this.bt_pyramidTexture.Location = new System.Drawing.Point(258, 33);
            this.bt_pyramidTexture.Name = "bt_pyramidTexture";
            this.bt_pyramidTexture.Size = new System.Drawing.Size(75, 23);
            this.bt_pyramidTexture.TabIndex = 6;
            this.bt_pyramidTexture.Text = "pyramidTexture";
            this.bt_pyramidTexture.UseVisualStyleBackColor = true;
            this.bt_pyramidTexture.Click += new System.EventHandler(this.bt_pyramidTexture_Click);
            // 
            // bt_dich
            // 
            this.bt_dich.Location = new System.Drawing.Point(12, 3);
            this.bt_dich.Name = "bt_dich";
            this.bt_dich.Size = new System.Drawing.Size(75, 23);
            this.bt_dich.TabIndex = 7;
            this.bt_dich.Text = "dich";
            this.bt_dich.UseVisualStyleBackColor = true;
            this.bt_dich.Click += new System.EventHandler(this.bt_dich_Click);
            // 
            // lb_x
            // 
            this.lb_x.AutoSize = true;
            this.lb_x.Location = new System.Drawing.Point(93, 9);
            this.lb_x.Name = "lb_x";
            this.lb_x.Size = new System.Drawing.Size(17, 13);
            this.lb_x.TabIndex = 8;
            this.lb_x.Text = "X:";
            // 
            // tb_dichX
            // 
            this.tb_dichX.Location = new System.Drawing.Point(116, 5);
            this.tb_dichX.Name = "tb_dichX";
            this.tb_dichX.Size = new System.Drawing.Size(31, 20);
            this.tb_dichX.TabIndex = 9;
            this.tb_dichX.TextChanged += new System.EventHandler(this.tb_dichX_TextChanged);
            // 
            // lb_y
            // 
            this.lb_y.AutoSize = true;
            this.lb_y.Location = new System.Drawing.Point(153, 9);
            this.lb_y.Name = "lb_y";
            this.lb_y.Size = new System.Drawing.Size(17, 13);
            this.lb_y.TabIndex = 10;
            this.lb_y.Text = "Y:";
            // 
            // tb_dichY
            // 
            this.tb_dichY.Location = new System.Drawing.Point(176, 5);
            this.tb_dichY.Name = "tb_dichY";
            this.tb_dichY.Size = new System.Drawing.Size(34, 20);
            this.tb_dichY.TabIndex = 11;
            this.tb_dichY.TextChanged += new System.EventHandler(this.tb_dichY_TextChanged);
            // 
            // lb_z
            // 
            this.lb_z.AutoSize = true;
            this.lb_z.Location = new System.Drawing.Point(216, 9);
            this.lb_z.Name = "lb_z";
            this.lb_z.Size = new System.Drawing.Size(17, 13);
            this.lb_z.TabIndex = 12;
            this.lb_z.Text = "Z:";
            // 
            // tb_dichZ
            // 
            this.tb_dichZ.Location = new System.Drawing.Point(239, 5);
            this.tb_dichZ.Name = "tb_dichZ";
            this.tb_dichZ.Size = new System.Drawing.Size(33, 20);
            this.tb_dichZ.TabIndex = 13;
            this.tb_dichZ.TextChanged += new System.EventHandler(this.tb_dichZ_TextChanged);
            // 
            // bt_scale
            // 
            this.bt_scale.Location = new System.Drawing.Point(285, 4);
            this.bt_scale.Name = "bt_scale";
            this.bt_scale.Size = new System.Drawing.Size(75, 23);
            this.bt_scale.TabIndex = 14;
            this.bt_scale.Text = "Scale";
            this.bt_scale.UseVisualStyleBackColor = true;
            this.bt_scale.Click += new System.EventHandler(this.bt_scale_Click);
            // 
            // lb_scaleX
            // 
            this.lb_scaleX.AutoSize = true;
            this.lb_scaleX.Location = new System.Drawing.Point(366, 9);
            this.lb_scaleX.Name = "lb_scaleX";
            this.lb_scaleX.Size = new System.Drawing.Size(17, 13);
            this.lb_scaleX.TabIndex = 15;
            this.lb_scaleX.Text = "X:";
            // 
            // tb_scaleX
            // 
            this.tb_scaleX.Location = new System.Drawing.Point(389, 6);
            this.tb_scaleX.Name = "tb_scaleX";
            this.tb_scaleX.Size = new System.Drawing.Size(36, 20);
            this.tb_scaleX.TabIndex = 16;
            this.tb_scaleX.TextChanged += new System.EventHandler(this.tb_scaleX_TextChanged);
            // 
            // lb_scaley
            // 
            this.lb_scaley.AutoSize = true;
            this.lb_scaley.Location = new System.Drawing.Point(431, 9);
            this.lb_scaley.Name = "lb_scaley";
            this.lb_scaley.Size = new System.Drawing.Size(17, 13);
            this.lb_scaley.TabIndex = 17;
            this.lb_scaley.Text = "Y:";
            // 
            // tb_scaley
            // 
            this.tb_scaley.Location = new System.Drawing.Point(454, 7);
            this.tb_scaley.Name = "tb_scaley";
            this.tb_scaley.Size = new System.Drawing.Size(39, 20);
            this.tb_scaley.TabIndex = 18;
            this.tb_scaley.TextChanged += new System.EventHandler(this.tb_scaley_TextChanged);
            // 
            // lb_scalez
            // 
            this.lb_scalez.AutoSize = true;
            this.lb_scalez.Location = new System.Drawing.Point(499, 10);
            this.lb_scalez.Name = "lb_scalez";
            this.lb_scalez.Size = new System.Drawing.Size(17, 13);
            this.lb_scalez.TabIndex = 19;
            this.lb_scalez.Text = "Z:";
            // 
            // tb_scalez
            // 
            this.tb_scalez.Location = new System.Drawing.Point(522, 7);
            this.tb_scalez.Name = "tb_scalez";
            this.tb_scalez.Size = new System.Drawing.Size(43, 20);
            this.tb_scalez.TabIndex = 20;
            this.tb_scalez.TextChanged += new System.EventHandler(this.tb_scalez_TextChanged);
            // 
            // bt_xoay
            // 
            this.bt_xoay.Location = new System.Drawing.Point(582, 6);
            this.bt_xoay.Name = "bt_xoay";
            this.bt_xoay.Size = new System.Drawing.Size(75, 23);
            this.bt_xoay.TabIndex = 21;
            this.bt_xoay.Text = "xoay";
            this.bt_xoay.UseVisualStyleBackColor = true;
            this.bt_xoay.Click += new System.EventHandler(this.bt_xoay_Click);
            // 
            // lb_xoayx
            // 
            this.lb_xoayx.AutoSize = true;
            this.lb_xoayx.Location = new System.Drawing.Point(663, 10);
            this.lb_xoayx.Name = "lb_xoayx";
            this.lb_xoayx.Size = new System.Drawing.Size(17, 13);
            this.lb_xoayx.TabIndex = 22;
            this.lb_xoayx.Text = "X:";
            // 
            // tb_xoayx
            // 
            this.tb_xoayx.Location = new System.Drawing.Point(686, 7);
            this.tb_xoayx.Name = "tb_xoayx";
            this.tb_xoayx.Size = new System.Drawing.Size(37, 20);
            this.tb_xoayx.TabIndex = 23;
            this.tb_xoayx.TextChanged += new System.EventHandler(this.tb_xoayx_TextChanged);
            // 
            // lb_xoayy
            // 
            this.lb_xoayy.AutoSize = true;
            this.lb_xoayy.Location = new System.Drawing.Point(729, 11);
            this.lb_xoayy.Name = "lb_xoayy";
            this.lb_xoayy.Size = new System.Drawing.Size(17, 13);
            this.lb_xoayy.TabIndex = 24;
            this.lb_xoayy.Text = "Y:";
            // 
            // tb_xoayy
            // 
            this.tb_xoayy.Location = new System.Drawing.Point(752, 8);
            this.tb_xoayy.Name = "tb_xoayy";
            this.tb_xoayy.Size = new System.Drawing.Size(40, 20);
            this.tb_xoayy.TabIndex = 25;
            this.tb_xoayy.TextChanged += new System.EventHandler(this.tb_xoayy_TextChanged);
            // 
            // lb_xoayz
            // 
            this.lb_xoayz.AutoSize = true;
            this.lb_xoayz.Location = new System.Drawing.Point(798, 10);
            this.lb_xoayz.Name = "lb_xoayz";
            this.lb_xoayz.Size = new System.Drawing.Size(17, 13);
            this.lb_xoayz.TabIndex = 26;
            this.lb_xoayz.Text = "Z:";
            // 
            // tb_xoayz
            // 
            this.tb_xoayz.Location = new System.Drawing.Point(821, 8);
            this.tb_xoayz.Name = "tb_xoayz";
            this.tb_xoayz.Size = new System.Drawing.Size(45, 20);
            this.tb_xoayz.TabIndex = 27;
            this.tb_xoayz.TextChanged += new System.EventHandler(this.tb_xoayz_TextChanged);
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(552, 36);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(457, 45);
            this.listView1.TabIndex = 28;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.listView1_MouseClick);
            // 
            // tb_bankinh
            // 
            this.tb_bankinh.Location = new System.Drawing.Point(471, 36);
            this.tb_bankinh.Name = "tb_bankinh";
            this.tb_bankinh.Size = new System.Drawing.Size(57, 20);
            this.tb_bankinh.TabIndex = 29;
            this.tb_bankinh.TextChanged += new System.EventHandler(this.tb_bankinh_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(420, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "bankinh";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1212, 475);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_bankinh);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.tb_xoayz);
            this.Controls.Add(this.lb_xoayz);
            this.Controls.Add(this.tb_xoayy);
            this.Controls.Add(this.lb_xoayy);
            this.Controls.Add(this.tb_xoayx);
            this.Controls.Add(this.lb_xoayx);
            this.Controls.Add(this.bt_xoay);
            this.Controls.Add(this.tb_scalez);
            this.Controls.Add(this.lb_scalez);
            this.Controls.Add(this.tb_scaley);
            this.Controls.Add(this.lb_scaley);
            this.Controls.Add(this.tb_scaleX);
            this.Controls.Add(this.lb_scaleX);
            this.Controls.Add(this.bt_scale);
            this.Controls.Add(this.tb_dichZ);
            this.Controls.Add(this.lb_z);
            this.Controls.Add(this.tb_dichY);
            this.Controls.Add(this.lb_y);
            this.Controls.Add(this.tb_dichX);
            this.Controls.Add(this.lb_x);
            this.Controls.Add(this.bt_dich);
            this.Controls.Add(this.bt_pyramidTexture);
            this.Controls.Add(this.bt_color);
            this.Controls.Add(this.BT_langtru);
            this.Controls.Add(this.bt_Pyramid);
            this.Controls.Add(this.bt_cube);
            this.Controls.Add(this.openGLControl);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.openGLControl)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private SharpGL.OpenGLControl openGLControl;
        private System.Windows.Forms.Button bt_cube;
        private System.Windows.Forms.Button bt_Pyramid;
        private System.Windows.Forms.Button BT_langtru;
        private System.Windows.Forms.Button bt_color;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.Button bt_pyramidTexture;
        private System.Windows.Forms.Button bt_dich;
        private System.Windows.Forms.Label lb_x;
        private System.Windows.Forms.TextBox tb_dichX;
        private System.Windows.Forms.Label lb_y;
        private System.Windows.Forms.TextBox tb_dichY;
        private System.Windows.Forms.Label lb_z;
        private System.Windows.Forms.TextBox tb_dichZ;
        private System.Windows.Forms.Button bt_scale;
        private System.Windows.Forms.Label lb_scaleX;
        private System.Windows.Forms.TextBox tb_scaleX;
        private System.Windows.Forms.Label lb_scaley;
        private System.Windows.Forms.TextBox tb_scaley;
        private System.Windows.Forms.Label lb_scalez;
        private System.Windows.Forms.TextBox tb_scalez;
        private System.Windows.Forms.Button bt_xoay;
        private System.Windows.Forms.Label lb_xoayx;
        private System.Windows.Forms.TextBox tb_xoayx;
        private System.Windows.Forms.Label lb_xoayy;
        private System.Windows.Forms.TextBox tb_xoayy;
        private System.Windows.Forms.Label lb_xoayz;
        private System.Windows.Forms.TextBox tb_xoayz;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TextBox tb_bankinh;
        private System.Windows.Forms.Label label1;
    }
}

